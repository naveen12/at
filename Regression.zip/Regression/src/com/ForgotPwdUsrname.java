package com;

import java.io.File;
import java.lang.reflect.Method;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ForgotPwdUsrname extends Info{
@BeforeSuite
	public void beforesuite(){
	  extent = new ExtentReports("D://Automation_Testing//EclipseProjects//Regression//Result//Create_account_report1.html",true);
	  extent.loadConfig(new File("D://Automation_Testing//EclipseProjects//Regression//extent-config.xml"));
	}
@BeforeMethod
	public void beforeMethod(Method method) {
		test= extent.startTest((this.getClass().getSimpleName() + " :: " + method.getName()), method.getName());
		test.assignAuthor("Naveen");
		test.assignCategory("Create_account test report");
	}
	

	public static void ForgotUserId(){
		
	}
	
	public static void ForgotPassword(){
		
	}












@AfterMethod
	public void afterMethod() {
		 extent.endTest(test);
	}
@AfterSuite
	public void aftetsuite(){
		  
		//  driver.close();
		  test.log(LogStatus.PASS, "Browser closed successfully");
		  extent.flush();
		  extent.close();
	}
	
}
