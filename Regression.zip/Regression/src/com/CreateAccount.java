package com;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class CreateAccount extends Info{
	/// This below test cases need to be update as per the if else conditions 
@BeforeSuite
	public void beforesuite(){
	  extent = new ExtentReports("D://Automation_Testing//EclipseProjects//Regression//Result//Create_account_report1.html",true);
	  extent.loadConfig(new File("D://Automation_Testing//EclipseProjects//Regression//extent-config.xml"));
	}
@BeforeMethod
	public void beforeMethod(Method method) {
		test= extent.startTest((this.getClass().getSimpleName() + " :: " + method.getName()), method.getName());
		test.assignAuthor("Naveen");
		test.assignCategory("Create_account test report");
	}
	
@Test (priority = 0)	
	public static void Startup() throws InterruptedException{	
		LoadBrowser();
		System.out.println("Test case 0");
		//CreateAccountPage();
		// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[7]/td[2]/div/a/span/b")));
	}
	public static void CreateAccountPage() throws InterruptedException{
		//long timeoutInSeconds = 10;
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[7]/td[2]/div/a/span/b")));
		
		driver.findElement(By.xpath("//tr[7]/td[2]/div/a/span/b")).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		int total_frames=driver.findElements(By.tagName("iframe")).size();
	    System.out.println("frames"+total_frames);
	    driver.switchTo().frame(0);
	    System.out.println("Entered Registration Page ........................");
	    test.log(LogStatus.PASS, "Entered Registration Page");
	}
@Test (priority = 1)
	public static void PatientMatch() throws InterruptedException{
		//Startup();
		System.out.println("Test case 1");
		CreateAccountPage();
		System.out.println("Entered Patient match page");
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(firstName);
		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(lastName);
		driver.findElement(By.xpath("//input[@id='birthdayMonth']")).sendKeys(birthdayMonth);
		driver.findElement(By.xpath("//input[@id='birthdayDate']")).sendKeys(birthdayDate);
		driver.findElement(By.xpath("//input[@id='birthdayYear']")).sendKeys(birthdayYear);
		System.out.println("Details are entered");
		test.log(LogStatus.PASS, "Details are entered");		
		}
@Test (priority = 2)
	public static void PatientMatchwithSSN() throws InterruptedException, IOException{
	//	PatientMatch();
		System.out.println("Test case 2");
		System.out.println("*******************PatientMatchwithSSN*******************");
		boolean usessn=driver.findElements(By.xpath("//div[@id='avmTDLink']/a/u")).size()!= 0;
		if(usessn=true){
			driver.findElement(By.xpath("//input[@name='socialSecurityNumber']")).sendKeys(socialSecurityNumber);
			driver.findElement(By.xpath("//td[4]/div/a/span")).click();
			if(driver.findElement(By.xpath("//input[@id='emailAddress']")).isDisplayed()){
				test.log(LogStatus.PASS, "test case = PatientMatchwithSSN");
				test.log(LogStatus.PASS, "test case passed successfully");
				
				}else{
					test.log(LogStatus.FAIL, "Details are not matched");
					File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\PatientMatchwithSSN1.png"), true);
				}
			driver.switchTo().defaultContent();
			driver.findElement(By.xpath("//div[2]/a/img")).click();
			System.out.println("close the window");
		//	driver.switchTo().defaultContent();
			}else{
				test.log(LogStatus.FAIL, "test case failed");
			}driver.switchTo().defaultContent();
	}

		
	
@Test (priority = 3)
	public static void PatientMatchNonSSNcell() throws InterruptedException, IOException{
		System.out.println("Test case 3");
		System.out.println("*******************PatientMatchNonSSNcell*******************");
		driver.switchTo().defaultContent();
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[7]/td[2]/div/a/span/b")));
		int total_frames=driver.findElements(By.tagName("iframe")).size();
	    System.out.println("frames"+total_frames);
		driver.findElement(By.xpath("//tr[7]/td[2]/div/a/span/b")).click();
	    driver.switchTo().frame(0);
	    driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(firstName);
		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(lastName);
		driver.findElement(By.xpath("//input[@id='birthdayMonth']")).sendKeys(birthdayMonth);
		driver.findElement(By.xpath("//input[@id='birthdayDate']")).sendKeys(birthdayDate);
		driver.findElement(By.xpath("//input[@id='birthdayYear']")).sendKeys(birthdayYear);
		driver.findElement(By.xpath("//div[@id='avmTDLink']/a/u")).click();
		driver.findElement(By.xpath("//input[@id='cellPhoneRadio']")).click();
		driver.findElement(By.xpath("//input[@id='cellPhoneText']")).clear();
		driver.findElement(By.xpath("//input[@id='cellPhoneText']")).sendKeys(cellPhoneText);
		driver.findElement(By.xpath("//td[4]/div/a/span")).click();
		if(driver.findElement(By.xpath("//input[@id='emailAddress']")).isDisplayed()){
			test.log(LogStatus.PASS, "test case = PatientMatchNonSSNCell");
			test.log(LogStatus.PASS, "test case passed successfully");
			driver.switchTo().defaultContent();
			driver.findElement(By.xpath("//div[2]/a/img")).click();
			System.out.println("window CLOSED");
			driver.switchTo().defaultContent();
		}else{
			test.log(LogStatus.FAIL, "Details are not matched");
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\PatientMatchNonSSNcell1.png"), true);
		}
	}
@Test (priority = 4) /// the portal page showing wrong validations  	
	public static void PatientMatchNonSSNcityzip() throws InterruptedException, IOException{
		System.out.println("Test case 4");
		System.out.println("*******************PatientMatchNonSSNcityzip*******************");
		driver.switchTo().defaultContent();
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
		int total_frames=driver.findElements(By.tagName("iframe")).size();
	    System.out.println("frames"+total_frames);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[7]/td[2]/div/a/span/b")));
		driver.findElement(By.xpath("//tr[7]/td[2]/div/a/span/b")).click();
	    driver.switchTo().frame(0);
	    driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(firstName);
		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(lastName);
		driver.findElement(By.xpath("//input[@id='birthdayMonth']")).sendKeys(birthdayMonth);
		driver.findElement(By.xpath("//input[@id='birthdayDate']")).sendKeys(birthdayDate);
		driver.findElement(By.xpath("//input[@id='birthdayYear']")).sendKeys(birthdayYear);
		driver.findElement(By.xpath("//div[@id='avmTDLink']/a/u")).click();
		driver.findElement(By.xpath("//input[@id='cityRadioText']")).click();
		driver.findElement(By.xpath("//input[@id='cityText']")).clear();
		driver.findElement(By.xpath("//input[@id='cityText']")).sendKeys(cityText);    // here needs to clarity
		driver.findElement(By.xpath("//input[@id='zipText']")).clear();
		driver.findElement(By.xpath("//input[@id='zipText']")).sendKeys(zip); 
		driver.findElement(By.xpath("//td[4]/div/a/span")).click();
		if(driver.findElement(By.xpath("//input[@id='emailAddress']")).isDisplayed()){
			test.log(LogStatus.PASS, "test case = PatientMatchNonSSNcityzip");
			test.log(LogStatus.PASS, "test case passed successfully");
		}else{
			test.log(LogStatus.FAIL, "Details are not matched");
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\PatientMatchNonSSNcityzip1.png"), true);
		}
	}

@Test (priority = 5)
	public static void UserSetup() throws InterruptedException, IOException{
		System.out.println("Test case 5");
		//PatientMatchNonSSNcityzip();
		System.out.println("Entered in Usersetup module");
		driver.findElement(By.xpath("//input[@id='emailAddress']")).clear();
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys(create_email);
		driver.findElement(By.xpath("//a/span")).click();
		driver.findElement(By.xpath("//input[@id='sameInfo']")).click();
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(create_Password);
		System.out.println("Usersetup module-password    "+ create_Password);
		driver.findElement(By.xpath("//input[@name='confirmPassword']")).sendKeys(create_confirm_Password);
		System.out.println("Usersetup module-confirm password     "+ create_confirm_Password);
		Select dropdown1 = new Select(driver.findElement(By.id("selectedQuestion")));
	    dropdown1.selectByIndex(0);	   
		driver.findElement(By.xpath("//input[@id='securityAnswer']")).sendKeys("surat");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[contains(@href, 'javascript:next();')]")).click();
		System.out.println("Next button");
		
		if(driver.findElement(By.xpath("//input[@id='Agree']")).isDisplayed()){
			System.out.println("Usersetup module- completed");
			test.log(LogStatus.PASS, "test case = UserSetup process completed");
			test.log(LogStatus.PASS, "test case passed successfully");
			
			}else{
				System.out.println("Usersetup module- failed");
				test.log(LogStatus.FAIL, "Details are not matched");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\UserSetup1.png"), true);
			}
		
		
	}
@Test (priority = 6)
	public static void UserAgreement() throws IOException{
		System.out.println("Test case 6");	
		System.out.println("UserAgreement module- stated");
	//	if(driver.findElement(By.xpath("//input[@id='Agree']")).isDisplayed()){
		driver.findElement(By.id("Agree")).click();
		driver.findElement(By.id("IUnderstand")).click();
		driver.findElement(By.xpath("//a/span")).click();
		assertEquals(closeAlertAndGetItsText(), "You must verify that you agree with terms and conditions is required");
		driver.findElement(By.id("Agree")).click();
		driver.findElement(By.xpath("//a/span")).click();
		if(driver.findElement(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[7]/td/div/div/div/table/tbody/tr[2]/td")).getText().equalsIgnoreCase("Congratulations, Test!")){	
			System.out.println("UserAgreement module- completed");
			test.log(LogStatus.PASS, "test case = UserAgreement process completed");
			test.log(LogStatus.PASS, "test case passed successfully");
			
			}else{
				System.out.println("UserAgreement module- failed");
				test.log(LogStatus.FAIL, "UserAgreement module- failed");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\UserAgreement1.png"), true);
			}
	}

@Test (priority = 7)
	public static void EmailVerification(){
		System.out.println("Test case 7");
		System.out.println("E-mail Verification- starting............");
		driver.findElement(By.xpath("//a/span")).click();
		System.out.println("E-mail Verification - completed..................");
	}
// destructive test case
@Test (priority = 8)
	public static void Re_patientMatch() throws InterruptedException, IOException{
	//	Startup();
		System.out.println("Test case 8");
		CreateAccountPage();
		boolean b= driver.findElement(By.xpath("//input[@name='firstName']")) != null;
		if(b=true){
			System.out.println("firstname, lastname fields are blank");
			test.log(LogStatus.PASS, "test case passed successfully");
		}else{
			System.out.println("firstname, lastname fields are have values");
			test.log(LogStatus.FAIL, "test case failed");
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\Re_patientMatch1.png"), true);
		}
		}
@Test (priority = 9)
	public static void Re_emailuse() throws InterruptedException, IOException{
	//	Startup();
	//	CreateAccountPage();
		System.out.println("Test case 9");
		System.out.println("Entered Patient match page");
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(firstName);
		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(lastName);
		driver.findElement(By.xpath("//input[@id='birthdayMonth']")).sendKeys(birthdayMonth);
		driver.findElement(By.xpath("//input[@id='birthdayDate']")).sendKeys(birthdayDate);
		driver.findElement(By.xpath("//input[@id='birthdayYear']")).sendKeys(birthdayYear);
		driver.findElement(By.xpath("//input[@name='socialSecurityNumber']")).sendKeys(socialSecurityNumber);
		driver.findElement(By.xpath("//td[4]/div/a/span")).click();
		System.out.println("Entered in Usersetup module");
		driver.findElement(By.xpath("//input[@id='emailAddress']")).clear();
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys(create_email);
		driver.findElement(By.xpath("//a/span")).click();
		
		if(driver.findElement(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[6]/td/div/div/div/table/tbody/tr[4]/td[2]/a/u")).getText().equalsIgnoreCase("Forgot Password?")){
			System.out.println("Next available Appointments are displayed");
			test.log(LogStatus.PASS, "Next available Appointments are displayed");
			
			}else{
				System.out.println("Next available Appointments - failed");
				test.log(LogStatus.FAIL, "Next available Appointments - failed");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\ApptSearch1.png"), true);
			}

		
		
		
	}

@AfterMethod
public void afterMethod() {
	 extent.endTest(test);
}
@AfterSuite
public void aftetsuite(){
	  
	//  driver.close();
	  test.log(LogStatus.PASS, "Browser closed successfully");
	  extent.flush();
	  extent.close();
}
}
