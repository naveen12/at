package com;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.apache.commons.io.FileUtils;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.testng.annotations.Test;

public class Info {
	public static WebDriver driver;
	public static ExtentReports extent;
/*	public static String baseUrl = "https://patient.nuemd.com/publicdb";   //"https://stagingportal1.nuemd.com/Patient.jsp?id=dbcardio&redirect=false";                                   // data center = "https://patient.nuemd.com/publicdb";   //QA HF Post gres
	
	public static String username="autotest@nada.ltd";                       //"suresh11@yopmail.com";
//	public static String username="nkumar@ysmail.yosamail.com";
	public static String Password="Nuesoft12";*/
	
	
	// staging details
	public static String baseUrl = "https://stagingportal1.nuemd.com/Patient.jsp?id=dbcardio&redirect=false";  
	public static String username="autotest2@nada.ltd";                       
	public static String Password="Nuesoft11";
	
	
	
	public static boolean acceptNextAlert = true;
	public static boolean foundAlert = true;
	public static String downloadPath = "D:\\seleniumdownloads";
	public static ExtentTest test;
	public static String change_Password="Nuesoft13";
	public static String change_confirm_Password=change_Password;
// Create Account Elements and values	
	public static String firstName="Test";
	public static String lastName="Auto";
	public static String birthdayMonth="02";
	public static String birthdayDate="01";
	public static String birthdayYear="1996";
	public static String socialSecurityNumber="5555";
	public static String cellPhoneText="8313333333";
	public static String cityText="DAYTON";
	public static String zip="45454";
	public static String create_Password="Nuesoft11";
	public static String create_confirm_Password=create_Password;
	public static String create_email="autotest3@nada.ltd";                      //"fipep@amail13.com";
	public static String create_email_AR="nkumar@ysmail.yosamail.com";
	public static String invalid_socialSecurityNumber="1212";
	public static String email_Resuse="vide@amail.club";
	public static String ar_firstname="test5";
	public static String ar_lastname="aut";
	public static String ar_phone= "0012222222";
	public static String ar_email= "autorep@nada.ltd";  // "testuser@ysmail.yosamail.com";
	public static String ar_register_url="https://stagingportal1.nuemd.com/Verification.jsp?id=dbcardio&portaluseraction=PortalUserRegister&secureKey=1dd7870e-5029-48f3-ab8f-8eaf7c163944";
	public static String apptlocation="Alaska";
	public static String apptprovider="Test,EDI Dr.";
	public static String apptreason="06March2017";
	public static String apptnewlocation="Georgia Online Name";
	public static String apptlocation2="AK";
	public static String apptprovider2="Byers,P1, P2 MD";
	public static String apptreason2="X Ray";
	
	public static String FromDate;
	public static String FromMonth;
	public static String ToDate;
	public static String ToMonth;
	public static String FromTime;
	public static String ToTime; 
	
	public static String CurrentDate;
	public static String SevenDate;
	 
	public static String Monday;
	public static String Tuesday;
	public static String Wednesday;
	public static String Thursday;
	public static String Friday;
	public static String Saturday;
	public static String Sunday;
	public static String Address1= "Address1";
	public static String Address2= "Address2";
	public static String cityzip= "45454545";
	public static String homephone= "1234567891";
	public static String workphone= "123456789112345";
	public static String cellphone= "7894563214";
	public static String workemail= "abc@test.com";
	public static String EmergencyName= "iball";
	public static String EmergencyRelationship= "Brother";
	public static String EmergencyPhone= "4567891324";
	
	public static String relationship= "Brother";
	public static String EmergencyEmail= "xyz@test.com";
//	public static String cityzip= "45454545";
//	public static String cityzip= "45454545";
	
	public static long timeoutInSeconds = 10;
	
	public static int result1,result2;
	public static String today,yesterday;
	public static String MessageBody = "Inbox test mail";
	public static String longMessage = "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefgh";
	public static String ComposeSubject = "subject:Compose Test";
	public static String inboxsubject1;
	public static String ComposeBody = "Compose to practice test mail Body Test";
	
	public static String SentSubject1;
	public static String inboxsubject;
	public static String Refillbody="Refill testing with tool";
	public static String Questionbody="Question testing with tool";
	public static String MedicationRefillMessage;
	public static String MedicationQuestionMessage;
	public static String LabResultMessage;
	
	
	
	
// Practice login details	
	public String PracticeUrl= "https://stagingportal2.nuemd.com/Practice.jsp?id=dbcardio";
	public String PracticeUsername="naveen";
	public String PracticePassword="Nuesoft11";
	
	public static void LoadBrowser(){
		// Accessing Patient portal 
		System.setProperty("webdriver.firefox.marionette","D:\\Automation_Testing\\Tools\\Drivers\\geckodriver.exe");
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(baseUrl);
		System.out.println("URL loaded");
		driver.switchTo().defaultContent();
	}
	
	public static void login() throws InterruptedException{
		LoadBrowser();
		driver.findElement(By.id("userName")).clear();
		driver.findElement(By.id("userName")).sendKeys(username);
		driver.findElement(By.id("Password")).clear();
		driver.findElement(By.id("Password")).sendKeys(Password);
		driver.findElement(By.className("NWebButton3NewPrimary")).click();
		System.out.println("login success");
		test.log(LogStatus.PASS, "login success");
				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		boolean pgsql=driver.findElements(By.xpath("//span/b")).size()!= 0; 
		if(pgsql==false){
			System.out.println("if condition");
			framecount();
		} else {
			System.out.println("else condition");
			driver.findElement(By.xpath("//span/b")).click();
	//		System.out.println("selected postgres in combo box");
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			framecount();
		}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.switchTo().defaultContent();
		long timeoutInSeconds = 30;
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='messagesModule']/a/font")));
		WebElement element= driver.findElement(By.xpath("//a/div"));
		element.isDisplayed();
//		System.out.println("element = "+element);
//		System.out.println("waiting for the class load");
	}
	public static void framecount() throws InterruptedException{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		int total_frames=driver.findElements(By.tagName("iframe")).size();
	    System.out.println("frames"+total_frames);
	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    if(total_frames>1){
			driver.switchTo().frame(1);
			driver.findElement(By.xpath(".//*[@id='newFormFrame']/div[2]/table/tbody/tr[3]/td/a[2]/span")).click();
			System.out.println("skip button clicked"); 
		 }else{
			 System.out.println("main iframe");
		 }
	    }

	
	public static String closeAlertAndGetItsText() {
	    try {
	    	Alert alert = driver.switchTo().alert();
	    	String alertText = alert.getText();
	    	if (acceptNextAlert) {
	    		alert.accept();
	    		
	    		alert.equals(alertText);
		      	} else {
		      		alert.dismiss();
		      	}
		      	return alertText;
		    	} finally {
		    		acceptNextAlert = true;
		    }
		  }
	public static void dateCalculation(){
		Date dNow = new Date( );
		SimpleDateFormat ft1 = new SimpleDateFormat ("d");
	    today =ft1.format(dNow);
	    System.out.println("Current Date: " + today);
	    result1 = Integer.parseInt(today);
	    System.out.println(result1);
	    result2=result1-1;
	    yesterday=  new Integer(result2).toString();
	    		
	}
	
	
	public static void safeSelectCheckBoxes(int waitTime, WebElement... elements) throws Exception {
		WebElement checkElement = null;
		try {
			if (elements.length > 0) {
				for (WebElement currentElement : elements) {
					checkElement = currentElement;
					WebDriverWait wait = new WebDriverWait(driver, waitTime);
					wait.until(ExpectedConditions.elementToBeClickable(currentElement));

					WebElement checkBox = currentElement;
					if (checkBox.isSelected())
						System.out.println("CheckBox " + currentElement
								+ " is already selected");
					else
						checkBox.click();
				}
			} else {
				System.out.println("Expected atleast one element as argument to safeSelectCheckboxes function");
			}
		} catch (StaleElementReferenceException e) {
			System.out.println("Element - " + checkElement + " is not attached to the page document " + e.getStackTrace());
		} catch (NoSuchElementException e) {
			System.out.println("Element " + checkElement + " was not found in DOM" + e.getStackTrace());
		} catch (Exception e) {
			System.out.println("Unable to select checkbox " + e.getStackTrace());
		}
	}
	public void Logout() throws Exception{
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//td[6]/div/a/font")).click();
		System.out.println("User logout successfully");
		test.log(LogStatus.PASS, "User logout successfully");
	}
	public static void Practicelogin(){
		LoadBrowser();
		String PracticeUrl= "https://stagingportal2.nuemd.com/Practice.jsp?id=dbcardio";
		String PracticeUsername="naveen";
		String PracticePassword="Nuesoft11";
		
		driver.get(PracticeUrl);
		
		driver.findElement(By.xpath("//input[@id='userName']")).sendKeys(PracticeUsername);
		driver.findElement(By.xpath("//input[@id='Password']")).sendKeys(PracticePassword);
		driver.findElement(By.xpath("//a[@id='login']/span")).click();
	}
}
