package com;

import java.io.File;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class CreateAcctount_Destructive extends Info{
@BeforeSuite
	public void beforesuite(){
	  extent = new ExtentReports("D://Automation_Testing//EclipseProjects//Regression//Result//CreateAcctount_Destructive_report1.html",true);
	  extent.loadConfig(new File("D://Automation_Testing//EclipseProjects//Regression//extent-config.xml"));
	}
@BeforeMethod
	public void beforeMethod(Method method) {
		test= extent.startTest((this.getClass().getSimpleName() + " :: " + method.getName()), method.getName());
		test.assignAuthor("Naveen");
		test.assignCategory("CreateAcctount_Destructive test report");
	}	
	public static void LoadBrowser(){
		// Accessing Patient portal 
		System.setProperty("webdriver.firefox.marionette","D:\\Automation_Testing\\Tools\\Drivers\\geckodriver.exe");
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(baseUrl);
		System.out.println("Browser loaded");
	}
	public static void Startup(){	
		driver.switchTo().defaultContent();
		
		long timeoutInSeconds = 10;
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[7]/td[2]/div/a/span/b")));
		
		driver.findElement(By.xpath("//tr[7]/td[2]/div/a/span/b")).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		int total_frames=driver.findElements(By.tagName("iframe")).size();
	    System.out.println("frames"+total_frames);
	    driver.switchTo().frame(0);
	    System.out.println("Entered Registration Page ........................");
	    test.log(LogStatus.PASS, "Entered Registration Page");
	}
@Test (priority = 0)
	public static void invalidSSN(){
		LoadBrowser();
		Startup();
		System.out.println("Entered Patient match page- invalidSSN");
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(firstName);
		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(lastName);
		driver.findElement(By.xpath("//input[@id='birthdayMonth']")).sendKeys(birthdayMonth);
		driver.findElement(By.xpath("//input[@id='birthdayDate']")).sendKeys(birthdayDate);
		driver.findElement(By.xpath("//input[@id='birthdayYear']")).sendKeys(birthdayYear);
		driver.findElement(By.xpath("//input[@name='socialSecurityNumber']")).sendKeys(invalid_socialSecurityNumber);
		driver.findElement(By.xpath("//td[4]/div/a/span")).click();
		
		if(driver.findElement(By.xpath("//div[@id='error']/strong/ul/li")).isDisplayed()){
			test.log(LogStatus.PASS, "Patient not found. Please re-enter your information or contact your practice for more information regarding this issue.");
			test.log(LogStatus.PASS, "test case passed successfully");
			System.out.println("test case passed");
		}else{
			test.log(LogStatus.FAIL, "test case failed");
		}
	}
@Test (priority = 1)
	public static void blankValidation(){
		LoadBrowser();
		System.out.println("*******blankValidation******");
		Startup();
		driver.findElement(By.xpath("//td[4]/div/a/span")).click();
		
		if(driver.findElement(By.xpath("//div[@id='error']/strong/ul/li")).isDisplayed()){
			test.log(LogStatus.PASS, "Validations working fine");
			System.out.println("test case passed");
		}else{
			test.log(LogStatus.FAIL, "test case failed");
		}
	}
@Test (priority = 2)
	public static void validateEmail(){
		LoadBrowser();
		System.out.println("*******validateEmail******");
		Startup();
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(firstName);
		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(lastName);
		driver.findElement(By.xpath("//input[@id='birthdayMonth']")).sendKeys(birthdayMonth);
		driver.findElement(By.xpath("//input[@id='birthdayDate']")).sendKeys(birthdayDate);
		driver.findElement(By.xpath("//input[@id='birthdayYear']")).sendKeys(birthdayYear);
		driver.findElement(By.xpath("//input[@name='socialSecurityNumber']")).sendKeys(socialSecurityNumber);
		driver.findElement(By.xpath("//td[4]/div/a/span")).click();
		driver.findElement(By.xpath("//a/span")).click();
		if(driver.findElement(By.xpath("//div[@id='error']/strong/ul/li")).isDisplayed()){
			test.log(LogStatus.PASS, "Email Validation working fine");
			System.out.println("test case passed");
		}else{
			test.log(LogStatus.FAIL, "test case failed");
		}
	
	}
@Test (priority = 3)
	public static void RegisteredEmailUse(){
		LoadBrowser();
		System.out.println("*******RegisteredEmailUse******");
		Startup();
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(firstName);
		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(lastName);
		driver.findElement(By.xpath("//input[@id='birthdayMonth']")).sendKeys(birthdayMonth);
		driver.findElement(By.xpath("//input[@id='birthdayDate']")).sendKeys(birthdayDate);
		driver.findElement(By.xpath("//input[@id='birthdayYear']")).sendKeys(birthdayYear);
		driver.findElement(By.xpath("//input[@name='socialSecurityNumber']")).sendKeys(socialSecurityNumber);
		driver.findElement(By.xpath("//td[4]/div/a/span")).click();
		driver.findElement(By.xpath("//input[@id='emailAddress']")).clear();
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys(email_Resuse);
		driver.findElement(By.xpath("//a/span")).click();
		if(driver.findElement(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[6]/td/div/div/div/table/tbody/tr[2]/td[2]/span")).isDisplayed()){
			test.log(LogStatus.PASS, "Email Validation working fine");
			System.out.println("test case passed");
		}else{
			test.log(LogStatus.FAIL, "test case failed");
		}	
}
@Test (priority = 4)
	public static void UserSetupValidation(){
		LoadBrowser();
		System.out.println("*******UserSetupValidation******");
		Startup();
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(firstName);
		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(lastName);
		driver.findElement(By.xpath("//input[@id='birthdayMonth']")).sendKeys(birthdayMonth);
		driver.findElement(By.xpath("//input[@id='birthdayDate']")).sendKeys(birthdayDate);
		driver.findElement(By.xpath("//input[@id='birthdayYear']")).sendKeys(birthdayYear);
		driver.findElement(By.xpath("//input[@name='socialSecurityNumber']")).sendKeys(socialSecurityNumber);
		driver.findElement(By.xpath("//td[4]/div/a/span")).click();
		System.out.println("Entered in Usersetup module");
		driver.findElement(By.xpath("//input[@id='emailAddress']")).clear();
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys(create_email);
		driver.findElement(By.xpath("//a/span")).click();
		driver.findElement(By.xpath("//a/span")).click();
		System.out.println("Next button");
		if(driver.findElement(By.xpath(".//*[@id='error']/strong/ul")).isDisplayed()){
			test.log(LogStatus.PASS, "User Setup Validation working fine");
			System.out.println("test case passed");
		}else{
			test.log(LogStatus.FAIL, "User Setup validation not working, test case failed");
		}	
	}

@AfterMethod
public void afterMethod() {
	 extent.endTest(test);
	 driver.close();
}
@AfterSuite
public void aftetsuite(){
	  
	//  driver.close();
	  test.log(LogStatus.PASS, "Browser closed successfully");
	  extent.flush();
	  extent.close();
}	
	
}
