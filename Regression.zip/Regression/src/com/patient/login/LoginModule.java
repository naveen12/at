package com.patient.login;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.Info;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class LoginModule extends Info{
	@BeforeSuite
	public void beforesuite(){
	  extent = new ExtentReports("D://Automation_Testing//EclipseProjects//Regression//AppointmentFunctional_report.html",true);
	  extent.loadConfig(new File("D://Automation_Testing//EclipseProjects//Regression//extent-config.xml"));
	}
@BeforeMethod
	public void beforeMethod(Method method) {
		test= extent.startTest((this.getClass().getSimpleName() + " :: " + method.getName()), method.getName());
		test.assignAuthor("Naveen");
		test.assignCategory("AppointmentFunctional test report");
}


/*             2.1.1  Test to verify welcome message with patient name after PORTAL side Login
                 2.1.1.1  Test Steps
Access Patient Portal Link>>Enter the registered Username and Password>>Sign In
                 2.1.1.2  Expected Result
It should show Welcome Back, <First name> <Last name>. There shouldn�t be any extra space but one space between First name and last name.*/
	public static void info(){
		System.setProperty("webdriver.firefox.marionette","D:\\Automation_Testing\\Tools\\Drivers\\geckodriver.exe");
		driver = new FirefoxDriver();
		System.out.println("browser loaded");
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(baseUrl);
		System.out.println("URL loaded");
	}
@Test(priority = 0)
	public static void LoginValidateBlank() throws IOException{
		info();
		driver.findElement(By.id("userName")).clear();
		driver.findElement(By.id("Password")).clear();
		driver.findElement(By.className("NWebButton3NewPrimary")).click();
		if((driver.findElement(By.xpath(".//*[@id='checkUserName']/ul/li")).getText().equalsIgnoreCase("Please enter your e-mail address")) && 
				(driver.findElement(By.xpath(".//*[@id='checkPassword']/ul/li")).getText().equalsIgnoreCase("Please enter your password")))
		{
			System.out.println("Blank Email and Password validation working on Login Page");
			test.log(LogStatus.PASS, "Blank Email and Password validation working on Login Page");
			
			}else{
				System.out.println("Blank Email and Password validation not working on Login Page");
				test.log(LogStatus.FAIL, "Blank Email and Password validation not working on Login Page");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\LoginValidateBlank1.png"), true);
			}
	}
@Test(priority = 1)
	public static void LoginValidateBlankPassword() throws IOException{
		
		driver.findElement(By.id("userName")).clear();
		driver.findElement(By.id("userName")).sendKeys(username);
		driver.findElement(By.id("Password")).clear();
		driver.findElement(By.className("NWebButton3NewPrimary")).click();
		if((driver.findElement(By.xpath(".//*[@id='checkPassword']/ul/li")).getText().equalsIgnoreCase("Please enter your password")))
		{
			System.out.println("Blank Password validation working on Login Page");
			test.log(LogStatus.PASS, "Blank Password validation working on Login Page");
			
			}else{
				System.out.println("Blank Password validation not working on Login Page");
				test.log(LogStatus.FAIL, "Blank Password validation not working on Login Page");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\LoginValidateBlankPassword1.png"), true);
			}
	}

@Test(priority = 2)	
	public static void LoginValidateBlankUsername() throws IOException{
		
		driver.findElement(By.id("userName")).clear();
		driver.findElement(By.id("Password")).clear();
		driver.findElement(By.id("Password")).sendKeys(Password);
		driver.findElement(By.className("NWebButton3NewPrimary")).click();
		if((driver.findElement(By.xpath(".//*[@id='checkUserName']/ul/li")).getText().equalsIgnoreCase("Please enter your e-mail address")))
		{
			System.out.println("Blank Email validation working on Login Page");
			test.log(LogStatus.PASS, "Blank Email validation working on Login Page");
			
			}else{
				System.out.println("Blank Email validation not working on Login Page");
				test.log(LogStatus.FAIL, "Blank Email validation not working on Login Page");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\LoginValidateBlankUsername1.png"), true);
			}
	}
@Test(priority = 3)
	public static void HelpCheck() throws IOException{
		driver.findElement(By.xpath("//img[@alt='helpImage']")).click();
	//	driver.findElement(By.xpath("//div[@id='shlshowhelp']/div/a/img")).click();
		
		if((driver.findElement(By.xpath("//div[@id='shlshowhelp']/div/a/img")).isDisplayed()))
		{
			System.out.println("Help popup displayed on Login Page");
			test.log(LogStatus.PASS, "Help popup displayed on Login Page");
			driver.findElement(By.xpath("//div[@id='shlshowhelp']/div/a/img")).click();
			
			}else{
				System.out.println("Help popup not displayed on Login Page");
				test.log(LogStatus.FAIL, "Help popup not displayed on Login Page");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\HelpCheck1.png"), true);
			}
	}
	
	
	
	
	
@Test(priority = 4)
	public static void verifyLogin() throws InterruptedException, IOException{
		
		driver.findElement(By.id("userName")).clear();
		driver.findElement(By.id("userName")).sendKeys(username);
		driver.findElement(By.id("Password")).clear();
		driver.findElement(By.id("Password")).sendKeys(Password);
		driver.findElement(By.className("NWebButton3NewPrimary")).click();
		System.out.println("login success");
		test.log(LogStatus.PASS, "login success");
				
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		boolean pgsql=driver.findElements(By.xpath("//span/b")).size()!= 0; 
		if(pgsql==false){
			System.out.println("if condition");
			framecount();
		} else {
			System.out.println("else condition");
			driver.findElement(By.xpath("//span/b")).click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			framecount();
		}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.switchTo().defaultContent();
		long timeoutInSeconds = 30;
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='messagesModule']/a/font")));
		WebElement element= driver.findElement(By.xpath("//a/div"));
		element.isDisplayed();
		
		if(driver.findElement(By.xpath(".//*[@id='headerx']/div/table/tbody/tr[3]/td/div/span/span[1]")).getText().equalsIgnoreCase("Welcome back,")){
			System.out.println("Welcome and Patient name displayed");
			test.log(LogStatus.PASS, "Welcome and Patient name displayed");
			
			}else{
				System.out.println("Welcome and Patient name details not displayed");
				test.log(LogStatus.FAIL, "Welcome and Patient name details not displayed");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyLogin1.png"), true);
			}
			
	}
/*
              2.1.2  Test to verify main Tool bar after Log in
                 2.1.2.1  Test Steps
Access Patient Portal Link >>Enter the registered Username and Password>>Sign In >>observe Main toolbar
                 2.1.2.2  Expected Result
There should be five tabs available; Messages, Appointment, Health Information, Profile and Exit
 */	
@Test(priority = 5)
	public static void verifyTabs() throws IOException{
// Message		.//*[@id='messagesModule']/a
		// Appointment  .//*[@id='appointmentsModule']/a
		// Health Info   .//*[@id='clinicalinfoModule']/a
		// Forms         .//*[@id='interactiveforminfoModule']/a
		// Billing       .//*[@id='billinginfoModule']/a
		// Exit          .//*[@id='WebLayout-nav']/div/table/tbody/tr/td/div/table/tbody/tr[1]/td[6]/div/a
		driver.findElement(By.xpath("//div[@id='messagesModule']/a/font")).getTagName();
		System.out.println("Message tab"+ driver.findElement(By.xpath("//div[@id='messagesModule']/a/font")).getTagName());
		System.out.println("Home Page");
		if((driver.findElement(By.xpath(".//*[@id='messagesModule']/a")).getText().equalsIgnoreCase("Message")) && 
				(driver.findElement(By.xpath(".//*[@id='appointmentsModule']/a")).getText().equalsIgnoreCase("Appointment")) && 
				(driver.findElement(By.xpath(".//*[@id='clinicalinfoModule']/a")).getText().equalsIgnoreCase("Health Info")) &&
				(driver.findElement(By.xpath(".//*[@id='interactiveforminfoModule']/a")).getText().equalsIgnoreCase("Forms")) &&
				(driver.findElement(By.xpath(".//*[@id='billinginfoModule']/a")).getText().equalsIgnoreCase("Billing")) &&
				(driver.findElement(By.xpath(".//*[@id='WebLayout-nav']/div/table/tbody/tr/td/div/table/tbody/tr[1]/td[6]/div/a")).getText().equalsIgnoreCase("Exit")))
		{
			System.out.println("Message, Appointment, Health Info, Forms, Billing, Exit, tabs showing in Home Page");
			test.log(LogStatus.PASS, "Message, Appointment, Health Info, Forms, Billing, Exit, tabs showing in Home Page");
			
			}else{
				System.out.println("Message, Appointment, Health Info, Forms, Billing, Exit, tabs not showing in Home Page");
				test.log(LogStatus.FAIL, "Message, Appointment, Health Info, Forms, Billing, Exit, tabs showing in Home Page");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyTabs1.png"), true);
			}
	}



@AfterMethod
public void afterMethod() {
	 extent.endTest(test);
}
@AfterSuite
public void aftetsuite(){
	  
	  driver.close();
	  test.log(LogStatus.PASS, "Browser closed successfully");
	  extent.flush();
	  extent.close();
}
}
