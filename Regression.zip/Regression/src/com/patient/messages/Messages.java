package com.patient.messages;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.Info;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class Messages extends Info{
	@BeforeSuite
	public void beforesuite(){
	  extent = new ExtentReports("D://Automation_Testing//EclipseProjects//Regression//Result//Messages_report1.html",true);
	  extent.loadConfig(new File("D://Automation_Testing//EclipseProjects//Regression//extent-config.xml"));
	}
@BeforeMethod
	public void beforeMethod(Method method) {
		test= extent.startTest((this.getClass().getSimpleName() + " :: " + method.getName()), method.getName());
		test.assignAuthor("Naveen");
		test.assignCategory("Messages test report");
	}

/*  
Test case 1
1. Hit Message --> it will show 4 sub tabs Inbox, Compose, Sent, Trash */

@Test (priority = 0)
	public static void verifyMessageTabs() throws InterruptedException, IOException{
		login();
		if((driver.findElement(By.xpath(".//*[@id='mailtabs']/li[1]/a")).getText().equalsIgnoreCase("Inbox"))
				&& (driver.findElement(By.xpath(".//*[@id='mailtabs']/li[2]/a")).getText().equalsIgnoreCase("Compose"))
				&& (driver.findElement(By.xpath(".//*[@id='mailtabs']/li[3]/a")).getText().equalsIgnoreCase("Sent"))
				&& (driver.findElement(By.xpath(".//*[@id='mailtabs']/li[4]/a")).getText().equalsIgnoreCase("Trash"))){
				System.out.println("Four tabs = Inbox, Compose, Sent, Trash are showing ");
				test.log(LogStatus.PASS, "Four tabs = Inbox, Compose, Sent, Trash are showing");
			}else{
				System.out.println("Four tabs = Inbox, Compose, Sent, Trash are not showing ");
				test.log(LogStatus.FAIL, "Four tabs = Inbox, Compose, Sent, Trash are not showing");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyMessageTabs1.png"), true);
			}
	}

/*  
Test case 2
2. InBox validation test case */
@Test (priority = 1)
	public static void inboxValidationCheck() throws IOException{
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Inbox')]")));
			
		driver.findElement(By.xpath("//a[contains(text(),'Inbox')]")).click();
		driver.switchTo().frame("_ddajaxtabsiframe-mailcontainer");
		System.out.println("inbox");
		driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
		driver.findElement(By.xpath("//div[@id='OSHmessage_q1']/a")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@id='msgReply0']/span")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.id("messageTextArea")).clear();
		driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
		if(driver.findElement(By.xpath(".//*[@id='error']/strong/ul/li")).getText().equalsIgnoreCase("Message body should not be blank")){
			System.out.println("Message body should not be blank");
			test.log(LogStatus.PASS, "Message body should not be blank");
			test.log(LogStatus.PASS, "test case passed successfully");
			
			}else{
				System.out.println("Message body blank testcase - failed");
				test.log(LogStatus.FAIL, "Message body blank testcase - failed");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\inboxValidationCheck1.png"), true);
			}
}



/*  
Test case 3
3. InBox Message sent test case */
@Test (priority = 2)
	public static void inbox() throws InterruptedException, IOException{
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			for (int i = 0; i <1; i++)
			    {
			    	System.out.println(i);    		    
			    	String s=String.valueOf(i);
			    	driver.findElement(By.id("messageTextArea")).clear();
			    	driver.findElement(By.id("messageTextArea")).sendKeys(s);
			    	driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
			    	System.out.println("message sent"+s);
				//   driver.switchTo().parentFrame();   
		        }
			
			if(driver.findElement(By.xpath(".//*[@id='error']")).getText().equalsIgnoreCase("Message sent successfully")){
				System.out.println("Message sent successfully ");
				test.log(LogStatus.PASS, "Message sent successfully ");
				test.log(LogStatus.PASS, "test case passed successfully");
				
				}else{
					System.out.println("Inbox to Message sent testcase - failed");
					test.log(LogStatus.FAIL, "Inbox to Message sent testcase - failed");
					File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\inbox1.png"), true);
				}
			
		}

/*  
Test case 4
4. Inbox to sent verify subject and body */
@Test (priority = 3)
	public static void verifyInboxtoSent() throws InterruptedException, IOException{
		//login();
				//	driver.findElement(By.xpath("//ul[@id='mailtabs']/li[2]/a")).click();
		driver.switchTo().parentFrame();
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Inbox')]")));
		driver.findElement(By.xpath("//a[contains(text(),'Inbox')]")).click();
		driver.switchTo().frame("_ddajaxtabsiframe-mailcontainer");
		System.out.println("inbox");
		driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
		driver.findElement(By.xpath("//div[@id='OSHmessage_q1']/a")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[@id='msgReply0']/span")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		inboxsubject = driver.findElement(By.xpath(".//*[@id='studMessage']")).getAttribute("value");
		System.out.println(inboxsubject);
		driver.findElement(By.id("messageTextArea")).clear();
		driver.findElement(By.id("messageTextArea")).sendKeys(MessageBody);
		driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
		driver.switchTo().parentFrame();
		driver.findElement(By.xpath("//ul[@id='mailtabs']/li[3]/a")).click();   // sent tab
		driver.switchTo().frame("_ddajaxtabsiframe-mailcontainer");
		String SentSubject = driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[1]/td[3]")).getText();
		String SentMessageBody= driver.findElement(By.xpath(".//*[@id='OSHmessage_ac1']/textarea")).getText();
		System.out.println("SentMessageBody = "+SentMessageBody);
		System.out.println("SentSubject ="+SentSubject);
		if((inboxsubject.contains(SentSubject))&& (MessageBody.contains(SentMessageBody))){
			System.out.println("Subject & Body matched");
			test.log(LogStatus.PASS, "Subject & Body matched");
			}else{
				System.out.println("Subject & Body not matched");
				test.log(LogStatus.FAIL, "Subject & Body not matched");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyInboxtoSent1.png"), true);
			}
	}

/*  
Test case 5
5. Inbox to Trash verify subject and body */
@Test (priority = 4)
	public static void verifyInboxtoTrash() throws InterruptedException, IOException{

		//login();
		driver.switchTo().parentFrame();
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Inbox')]")));
		driver.findElement(By.xpath("//a[contains(text(),'Inbox')]")).click();
		driver.switchTo().frame("_ddajaxtabsiframe-mailcontainer");
		System.out.println("inbox");
		driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr/td[1]/div")).click();    //  select one mail
		System.out.println("select mail");
		inboxsubject1 = driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr/td[3]")).getText(); // collect subject from inbox
		System.out.println("inboxsubject1 = "+inboxsubject1);
		//driver.findElement(By.xpath("//table[@id='tableId']/tbody/tr/td/form/table/tbody/tr[23]/td/table/tbody/tr/td/div/table/tbody/tr/td[3]/a/span")).click(); // delete
		driver.findElement(By.xpath("//td[3]/a/span")).click();
	
		driver.switchTo().parentFrame();
		driver.findElement(By.xpath("//a[contains(text(),'Trash')]")).click();   // trash tab
		driver.switchTo().frame("_ddajaxtabsiframe-mailcontainer");
		
		
		if(driver.findElement(By.xpath(".//*[@id='SHL_pagination']/span")).isDisplayed()){
		for (int i = 1; i <= 4; i++) {
			driver.findElement(By.xpath(".//*[@id='SHL_pagination']/a[" + i + "]")).click();
			for (int j = 1; j <= 5; j++) {
				String Cellvalue= driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[" + j + "]/td[3]")).getText();    // path
				if(Cellvalue.contains(inboxsubject1)){                  
					System.out.println("text Matched  " +inboxsubject1 );
					System.out.println("row = "+j);
					System.out.println("Page = "+i);
					System.out.println("Deleted Inbox-mail verified in Trash section ");
					test.log(LogStatus.PASS, "Deleted Inbox-mail verified in Trash section");
					break;
				}else{
					System.out.println("text not matched, Verification failed");
					test.log(LogStatus.FAIL, "text not matched, Verification failed");
					File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyInboxtoTrash1.png"), true);
				}}}}else{
					for (int k = 1; k <= 5; k++) {
						String Cellvalue= driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[" + k + "]/td[3]")).getText();    // path
						if(Cellvalue.contains(inboxsubject1)){                  
							System.out.println("text Matched  " +inboxsubject1 );
							System.out.println("row = "+k);
	//						System.out.println("Page = "+i);
							System.out.println("Deleted Inbox-mail verified in Trash section ");
							test.log(LogStatus.PASS, "Deleted Inbox-mail verified in Trash section");
							break;
						}else{
							System.out.println("text not matched, Verification failed");
							test.log(LogStatus.FAIL, "text not matched, Verification failed");
							File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
							FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyInboxtoTrash1.png"), true);
						}
				}
			}
		}


/*  
Test case 6
6. Trash to Inbox verify subject and body */
@Test (priority = 5)
	public static void verifyTrashToInbox() throws InterruptedException, IOException{
		driver.switchTo().parentFrame();
		driver.findElement(By.xpath("//a[contains(text(),'Trash')]")).click();   // trash tab
		driver.switchTo().frame("_ddajaxtabsiframe-mailcontainer");
		for (int i = 1; i <= 4; i++) {
			driver.findElement(By.xpath(".//*[@id='SHL_pagination']/a[" + i + "]")).click();
			for (int j = 1; j <= 5; j++) {
				String Cellvalue= driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[" + j + "]/td[3]")).getText();    // path
				if(Cellvalue.contains(inboxsubject1)){                  
					System.out.println("text Matched  " +inboxsubject1 );
					System.out.println("row = "+j);
					System.out.println("Page = "+i);
					
					driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[" + j + "]/td[1]")).click();   // clicking on checkbox
					driver.findElement(By.xpath(".//*[@id='tableId']/tbody/tr/td/form/table/tbody/tr[8]/td/table/tbody/tr/td/div/table/tbody/tr/td[2]/a")).click();
					
					driver.switchTo().parentFrame();
					WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);		
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Inbox')]")));
					driver.findElement(By.xpath("//a[contains(text(),'Inbox')]")).click();
					driver.switchTo().frame("_ddajaxtabsiframe-mailcontainer");
					System.out.println("inbox");
					driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr/td[1]/div")).click();    //  select one mail
					System.out.println("select mail");
					String inboxsubject2 = driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr/td[3]")).getText(); // collect subject from inbox
					System.out.println("inboxsubject2 = "+inboxsubject2);
					
					if(Cellvalue.contains(inboxsubject2)){
						System.out.println("Subject matched");
						}else{
						System.out.println("Subject not matched");
						}
					
					System.out.println("Mail restored from Trash to Inbox properly and verified ");
					test.log(LogStatus.PASS, "Mail restored from Trash to Inbox properly and verified");
					break;
				}else{
					System.out.println("Mail restore process failed");
					test.log(LogStatus.FAIL, "Mail restore process failed");
					File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyTrashToInbox1.png"), true);
				}
			}
		}
}


/*  
Test case 7
7. Compose Validation check */
@Test (priority = 6)
	public static void composeValidationCheck() throws IOException{
		driver.switchTo().parentFrame();
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Compose')]")));
		driver.findElement(By.xpath("//a[contains(text(),'Compose')]")).click();
		driver.switchTo().frame("_ddajaxtabsiframe-mailcontainer");
		System.out.println("Compose");
		
	//	driver.findElement(By.xpath("//input[@id='studMessage']")).sendKeys(ComposeSubject);
	//	driver.findElement(By.xpath("//textarea[@id='messageTextArea']")).sendKeys("Compose to practice test mail Body");
		driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
	
		if((driver.findElement(By.xpath(".//*[@id='error']/strong/ul/li[1]")).getText().equalsIgnoreCase("Message subject should not be blank"))&&
				(driver.findElement(By.xpath(".//*[@id='error']/strong/ul/li[2]")).getText().equalsIgnoreCase("Message body should not be blank"))){
			System.out.println("Compose Validation working properly ");
			test.log(LogStatus.PASS, "Compose Validation working properly ");
			}else{
				System.out.println("Compose Validation - failed");
				test.log(LogStatus.FAIL, "Compose Validation - failed");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\composeValidationCheck1.png"), true);
			}
}
/*  
Test case 8
8. Compose to Sent verification check */

@Test (priority = 7)
	public static void verifyComposetoSent() throws InterruptedException, IOException{
		//login();
		driver.switchTo().parentFrame();
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Compose')]")));
		driver.findElement(By.xpath("//a[contains(text(),'Compose')]")).click();
		driver.switchTo().frame("_ddajaxtabsiframe-mailcontainer");
		System.out.println("Compose");
		
		driver.findElement(By.xpath("//input[@id='studMessage']")).sendKeys(ComposeSubject);
		driver.findElement(By.xpath("//textarea[@id='messageTextArea']")).sendKeys(ComposeBody);
		driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
		driver.switchTo().parentFrame();
		driver.findElement(By.xpath("//ul[@id='mailtabs']/li[3]/a")).click();   // sent tab
		driver.switchTo().frame("_ddajaxtabsiframe-mailcontainer");
		
		for (int j = 1; j <= 5; j++) {
			String Cellvalue= driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[" + j + "]/td[3]")).getText();    // path
			if(ComposeSubject.contains(Cellvalue)){                  
				System.out.println("text Matched  " +ComposeSubject );
				System.out.println("Verification completed Compose mail subject and Sent Subject matched");
				test.log(LogStatus.PASS, "Verification completed Compose mail subject and Sent Subject matched");
			}else{
				System.out.println("Verification completed Compose mail subject and Sent Subject are not matched");
				test.log(LogStatus.FAIL, "Verification completed Compose mail subject and Sent Subject are not matched");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyComposetoSent1.png"), true);
		}}
}





/*  
Test case 10
10. Sent to Trash verification check */

@Test (priority = 9)
	public static void verifySentToTrash() throws InterruptedException, IOException{
	
		//login();	
		driver.switchTo().parentFrame();
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Sent')]")));
		driver.findElement(By.xpath("//a[contains(text(),'Sent')]")).click();
		driver.switchTo().frame("_ddajaxtabsiframe-mailcontainer");
		System.out.println("Sent");
		driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[1]/td[1]")).click();
		SentSubject1 = driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[1]/td[3]")).getText();
		System.out.println(SentSubject1);
		
		driver.findElement(By.xpath("//table[@id='tableId']/tbody/tr/td/form/table/tbody/tr[8]/td/table/tbody/tr/td/div/table/tbody/tr/td[2]/a/span")).click(); // delete
		driver.switchTo().parentFrame();
		driver.findElement(By.xpath("//a[contains(text(),'Trash')]")).click(); // Trash
		driver.switchTo().frame("_ddajaxtabsiframe-mailcontainer");
		
		String TrashSubject1 = driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[1]/td[3]")).getText();
		System.out.println(TrashSubject1);
	
		if(SentSubject1.contains(TrashSubject1)){
				System.out.println("Verification completed on Sent mail subject and Trash Subject matched");
				test.log(LogStatus.PASS, "Verification completed on Sent mail subject and Trash Subject matched");
		}else{
				System.out.println("Verification failed on Sent mail subject and Trash Subject matched - Failed");
				test.log(LogStatus.FAIL, "Verification failed on Sent mail subject and Trash Subject matched - Failed");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifySentToTrash1.png"), true);
				}
	//	.//*[@id='sortable']/tbody/tr[1]/td[3]
	//	driver.findElement(By.xpath("//table[@id='tableId']/tbody/tr/td/form/table/tbody/tr[8]/td/table/tbody/tr/td/div/table/tbody/tr/td[2]/a/span")).click();  // restore
		
		
	}

/*  
Test case 11
11. Trash to Sent verification check */

@Test (priority = 10)
	public static void verifyTrashToSent() throws InterruptedException, IOException{
	//	login();
		driver.switchTo().parentFrame();
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Trash')]")));
		driver.findElement(By.xpath("//a[contains(text(),'Trash')]")).click();
		driver.switchTo().frame("_ddajaxtabsiframe-mailcontainer");
		driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[1]/td[1]")).click();
		String trashSubject2 = driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[1]/td[3]")).getText();
		System.out.println(trashSubject2);
		
		driver.findElement(By.xpath("//table[@id='tableId']/tbody/tr/td/form/table/tbody/tr[8]/td/table/tbody/tr/td/div/table/tbody/tr/td[2]/a/span")).click(); // delete
		driver.switchTo().parentFrame();
		driver.findElement(By.xpath("//a[contains(text(),'Sent')]")).click(); // Trash
		driver.switchTo().frame("_ddajaxtabsiframe-mailcontainer");
		
	//	String TrashSubject1 = driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[1]/td[3]")).getText();
	//	System.out.println(TrashSubject1);
	
		if(SentSubject1.contains(trashSubject2)){
				System.out.println("Subject matched");
				System.out.println("Verification completed on Trash mail subject and Sent Subject matched");
				test.log(LogStatus.PASS, "Verification completed on Trash mail subject and Sent Subject matched");
		}else{
				System.out.println("Subject not matched");
				test.log(LogStatus.FAIL, "Verification failed on Trash mail subject and Sent Subject matched - Failed");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyTrashToSent1.png"), true);
				}
	//	.//*[@id='sortable']/tbody/tr[1]/td[3]
	//	driver.findElement(By.xpath("//table[@id='tableId']/tbody/tr/td/form/table/tbody/tr[8]/td/table/tbody/tr/td/div/table/tbody/tr/td[2]/a/span")).click();  // restore
		
		
	}





/*  
Test case 13
13. Access Health info --> Patient summary --> My Medications --> Refill    =  insert long text and check validation.
	check sent with subject and body */
@Test (priority = 12)

	public static void validateMedicationRefill() throws InterruptedException, IOException{
	//	login();
		driver.switchTo().parentFrame();
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='clinicalinfoModule']/a/font")));
		driver.findElement(By.xpath("//div[@id='clinicalinfoModule']/a/font")).click();
		driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a")).click(); // patient summary
		driver.findElement(By.xpath(".//*[@id='mailcontainer']/div[1]/table/tbody/tr/td/div/div/div/table/tbody/tr[1]/td[3]")).click(); // medication refill click
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.switchTo().frame(0);
		driver.findElement(By.xpath("//div[@id='rxRefillFrame']/div[2]/table/tbody/tr[4]/td/textarea")).sendKeys(longMessage);
		System.out.println("text entered");
		driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
		System.out.println("send button");
		// if else case
		
		if(driver.findElement(By.xpath("//button[@type='button']")).isDisplayed()){
			driver.findElement(By.xpath("//button[@type='button']")).click();
			driver.switchTo().defaultContent();
			driver.findElement(By.xpath("//img[@alt='Close Window']")).click();
			System.out.println("popup closed");
			System.out.println("Medication Refill validation working fine - it allowing only 2500 characters");
			test.log(LogStatus.PASS, "Medication Refill validation working fine - it allowing only 2500 characters");
		}else{
			test.log(LogStatus.FAIL, "Medication Refill validation check - failed");
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\validateMedicationRefill1.png"), true);
		}
		driver.switchTo().defaultContent();
		if(driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a")).isDisplayed()){
				System.out.println("111111111111 - Success");
				WebElement element= driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a"));
				WebDriverWait wait1 = new WebDriverWait(driver, timeoutInSeconds);
				wait1.until(ExpectedConditions.elementToBeClickable(element));

				driver.switchTo().defaultContent();

				driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();  
			
			}else{
				System.out.println("test case- failed");
			}
	}
	
/*  
Test case 14
14. Access Health info --> Patient summary --> My Medications --> Refill    =  insert some text and save it and cross verify in Sent tab.
	check sent with subject and body */
@Test (priority = 13)	
	public static void verifyMedicationRefilltoSent() throws InterruptedException, IOException{
	//	login();
		driver.switchTo().parentFrame();
		driver.findElement(By.xpath("//div[@id='clinicalinfoModule']/a/font")).click();
		driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a")).click(); // patient summary
		driver.findElement(By.xpath(".//*[@id='mailcontainer']/div[1]/table/tbody/tr/td/div/div/div/table/tbody/tr[1]/td[3]")).click(); // medication refill click
		String s =driver.findElement(By.xpath(".//*[@id='mailcontainer']/div[1]/table/tbody/tr/td/div/div/div/table/tbody/tr[1]/td[3]")).getText();
		System.out.println("title check "+s);
	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    driver.switchTo().frame(0);
		driver.findElement(By.xpath("//div[@id='rxRefillFrame']/div[2]/table/tbody/tr[4]/td/textarea")).clear();
	    driver.findElement(By.xpath("//div[@id='rxRefillFrame']/div[2]/table/tbody/tr[4]/td/textarea")).sendKeys(Refillbody);
		driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
		assertEquals(closeAlertAndGetItsText(), "Prescription Refill Request sent.");
		
	    driver.switchTo().defaultContent();
		String sCellValue = driver.findElement(By.xpath(".//*[@id='mailcontainer']/div[1]/table/tbody/tr/td/div/div/div/table/tbody/tr[1]/td[1]")).getText();
		System.out.println("Prescription Refill Request: "+sCellValue);
		System.out.println("test");
		
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		String date = sdf.format(new Date());
		System.out.println(date); //10/15/2013
	 
		driver.switchTo().parentFrame();
		driver.findElement(By.xpath("//div[@id='messagesModule']/a/font")).click();   // Messages
		driver.findElement(By.xpath("//ul[@id='mailtabs']/li[3]/a")).click();         // Sent
		driver.switchTo().frame("_ddajaxtabsiframe-mailcontainer");
		System.out.println("sent");
		
		String sCellDate1 = driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[1]/td[2]")).getText();
		System.out.println("Date: "+sCellDate1);
		
		String sCellSubject1 = driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[1]/td[3]")).getText();
		System.out.println(sCellSubject1);
		String refill ="Prescription Refill Request: ";
		MedicationRefillMessage = refill+sCellValue;
		System.out.println(MedicationRefillMessage);
		if(MedicationRefillMessage.equals(sCellSubject1) && date.equals(sCellDate1)){
			System.out.println("Medication Refill sent and verified in Sent folder");
			test.log(LogStatus.PASS, "Medication Refill mail sent and verified in Sent folder");
		}else{
			System.out.println("data not matched");
			test.log(LogStatus.FAIL, "Medication Refill mail sent and verification failed in Sent folder");
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyMedicationRefilltoSent1.png"), true);
		}
		driver.switchTo().defaultContent();
		if(driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a")).isDisplayed()){
				System.out.println("111111111111 - Success");
				WebElement element= driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a"));
				WebDriverWait wait1 = new WebDriverWait(driver, timeoutInSeconds);
				wait1.until(ExpectedConditions.elementToBeClickable(element));
			//	System.out.println("iiiiiiiiiiiiiiiiiiiiiiiiiiii");
				driver.switchTo().defaultContent();
			//	driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a")).click();
				driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();  
			
	//		test.log(LogStatus.PASS, "Authorized Representative module showing - Success");
			
			}else{
				System.out.println("test case- failed");
		//		test.log(LogStatus.FAIL, "Authorized Representative module- failed");
			}
	}

/*  
Test case 15
15. Access Health info --> Patient summary --> My Medications --> Question    =  insert long text and verify validation.
	check sent with subject and body */
@Test (priority = 14)	
	public static void validateMedicationQuestion() throws InterruptedException, IOException{
	//	login();
		driver.switchTo().parentFrame();
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='clinicalinfoModule']/a/font")));
		driver.findElement(By.xpath("//div[@id='clinicalinfoModule']/a/font")).click();
		driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a")).click(); // patient summary
		driver.findElement(By.xpath(".//*[@id='mailcontainer']/div[1]/table/tbody/tr/td/div/div/div/table/tbody/tr[1]/td[4]")).click(); // medication question click
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.switchTo().frame(0);
		driver.findElement(By.xpath("//div[@id='rxRefillFrame']/div[2]/table/tbody/tr[4]/td/textarea")).sendKeys(longMessage);
		System.out.println("text entered");
		driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
		System.out.println("send button");
		// if else case
		
		
		if(driver.findElement(By.xpath("//button[@type='button']")).isDisplayed()){
			driver.findElement(By.xpath("//button[@type='button']")).click();
			driver.switchTo().defaultContent();
			driver.findElement(By.xpath("//img[@alt='Close Window']")).click();
			System.out.println("popup closed");
			System.out.println("Medication Question validation working fine - it allowing only 2500 characters");
			test.log(LogStatus.PASS, "Medication Question validation working fine - it allowing only 2500 characters");
		}else{
			test.log(LogStatus.FAIL, "Medication Question validation check - failed");
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\validateMedicationQuestion1.png"), true);
		}
		
		driver.switchTo().defaultContent();
		if(driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a")).isDisplayed()){
				System.out.println("111111111111 - Success");
				WebElement element= driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a"));
				WebDriverWait wait1 = new WebDriverWait(driver, timeoutInSeconds);
				wait1.until(ExpectedConditions.elementToBeClickable(element));
			//	System.out.println("iiiiiiiiiiiiiiiiiiiiiiiiiiii");
				driver.switchTo().defaultContent();
			//	driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a")).click();
				driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();  
			
	//		test.log(LogStatus.PASS, "Authorized Representative module showing - Success");
			
			}else{
				System.out.println("test case- failed");
		//		test.log(LogStatus.FAIL, "Authorized Representative module- failed");
			}
		
		
	}

/*  
Test case 16
16. Access Health info --> Patient summary --> My Medications --> Question    =  insert some text and save it and cross verify in Sent tab.
	check sent with subject and body */
@Test (priority = 15)	
	public static void verifyMedicationQuestiontoSent() throws InterruptedException, IOException{
		//	login();
			driver.switchTo().parentFrame();
			WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='clinicalinfoModule']/a/font")));
			driver.findElement(By.xpath("//div[@id='clinicalinfoModule']/a/font")).click();
			driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a")).click(); // patient summary
			driver.findElement(By.xpath(".//*[@id='mailcontainer']/div[1]/table/tbody/tr/td/div/div/div/table/tbody/tr[1]/td[4]")).click();  // medication question click

			String s =driver.findElement(By.xpath(".//*[@id='mailcontainer']/div[1]/table/tbody/tr/td/div/div/div/table/tbody/tr[1]/td[4]")).getText();
			System.out.println("title check "+s);

		    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		    driver.switchTo().frame(0);
		    driver.findElement(By.xpath("//div[@id='rxRefillFrame']/div[2]/table/tbody/tr[4]/td/textarea")).clear();
		    driver.findElement(By.xpath("//div[@id='rxRefillFrame']/div[2]/table/tbody/tr[4]/td/textarea")).sendKeys(Questionbody);
			driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
			assertEquals(closeAlertAndGetItsText(), "Prescription question sent.");

		    driver.switchTo().defaultContent();
		    String sCellValue = driver.findElement(By.xpath(".//*[@id='mailcontainer']/div[1]/table/tbody/tr/td/div/div/div/table/tbody/tr[1]/td[1]")).getText();
			System.out.println("Prescription Question: "+sCellValue);
			System.out.println("test");
			
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			String date = sdf.format(new Date());
			System.out.println(date); //10/15/2013
		 
			driver.switchTo().parentFrame();
			driver.findElement(By.xpath("//div[@id='messagesModule']/a/font")).click();
			driver.findElement(By.xpath("//ul[@id='mailtabs']/li[3]/a")).click();
			driver.switchTo().frame("_ddajaxtabsiframe-mailcontainer");
			System.out.println("sent");
			
			String sCellDate1 = driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[1]/td[2]")).getText();
			System.out.println("Date: "+sCellDate1);
			
			String sCellSubject1 = driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[1]/td[3]")).getText();
			System.out.println(sCellSubject1);
			String refill ="Prescription Question: ";
			MedicationQuestionMessage = refill+sCellValue;
			System.out.println(MedicationQuestionMessage);
		///	System.out.println(refillMessage.equals(sCellValue2));//true  
			if(MedicationQuestionMessage.equals(sCellSubject1) && date.equals(sCellDate1)){
				System.out.println("Medication Refill sent and verified in Sent folder");
				test.log(LogStatus.PASS, "Medication Refill mail sent and verified in Sent folder");
			}else{
				System.out.println("data not matched");
				test.log(LogStatus.FAIL, "Medication Refill mail sent and verification failed in Sent folder");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyMedicationQuestiontoSent1.png"), true);
			}
			driver.switchTo().defaultContent();
			if(driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a")).isDisplayed()){
					System.out.println("111111111111 - Success");
					WebElement element= driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a"));
					WebDriverWait wait1 = new WebDriverWait(driver, timeoutInSeconds);
					wait1.until(ExpectedConditions.elementToBeClickable(element));
				//	System.out.println("iiiiiiiiiiiiiiiiiiiiiiiiiiii");
					driver.switchTo().defaultContent();
				//	driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a")).click();
					driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();  
				}else{
					System.out.println("test case- failed");
				}
		}



/*  
Test case 17
17. Access Health info --> Patient summary --> My Medications --> Question    =  insert long text and verify validation.
	check sent with subject and body */
@Test (priority = 16)	
	public static void validateLabResultQuestion() throws InterruptedException, IOException{
	//	login();
		driver.switchTo().parentFrame();
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='clinicalinfoModule']/a/font")));
		driver.findElement(By.xpath("//div[@id='clinicalinfoModule']/a/font")).click();
		driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a")).click(); // patient summary
		driver.findElement(By.xpath(".//*[@id='mailcontainer']/div[2]/table/tbody/tr/td/div/div/div/table/tbody/tr/td[5]")).click();
		//String s =driver.findElement(By.xpath(".//*[@id='mailcontainer']/div[2]/table/tbody/tr/td/div/div/div/table/tbody/tr/td[5]")).getText(); // medication question click
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.switchTo().frame(0);
		driver.findElement(By.xpath("//div[@id='rxRefillFrame']/div[2]/table/tbody/tr[4]/td/textarea")).sendKeys(longMessage);
		System.out.println("text entered");
		driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
		System.out.println("send button");
	
		if(driver.findElement(By.xpath("//button[@type='button']")).isDisplayed()){
			driver.findElement(By.xpath("//button[@type='button']")).click();
			driver.switchTo().defaultContent();
			driver.findElement(By.xpath("//img[@alt='Close Window']")).click();
			System.out.println("popup closed");
			System.out.println("Lab Result Question validation working fine - it allowing only 2500 characters");
			test.log(LogStatus.PASS, "Lab Result Question validation working fine - it allowing only 2500 characters");
		}else{
			test.log(LogStatus.FAIL, "Lab Result Question validation check - failed");
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\validateLabResultQuestion1.png"), true);
		}
		
		driver.switchTo().defaultContent();
		if(driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a")).isDisplayed()){
				System.out.println("111111111111 - Success");
				WebElement element= driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a"));
				WebDriverWait wait1 = new WebDriverWait(driver, timeoutInSeconds);
				wait1.until(ExpectedConditions.elementToBeClickable(element));
				driver.switchTo().defaultContent();
				driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();  
			}else{
				System.out.println("test case- failed");
			}
	}




/*  
Test case 18
18. Access Health info --> Patient summary --> My Lab --> Question    =  insert some text and save it and cross verify in Sent tab.
	check sent with subject and body */
@Test (priority = 17)	
	public static void verifyLabResultQuestionToSent() throws InterruptedException, IOException{
		
	//	login();
		driver.switchTo().parentFrame();
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='clinicalinfoModule']/a/font")));
		driver.findElement(By.xpath("//div[@id='clinicalinfoModule']/a/font")).click();
		driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a")).click(); // patient summary
		driver.findElement(By.xpath(".//*[@id='mailcontainer']/div[2]/table/tbody/tr/td/div/div/div/table/tbody/tr/td[5]")).click();
		String s =driver.findElement(By.xpath(".//*[@id='mailcontainer']/div[2]/table/tbody/tr/td/div/div/div/table/tbody/tr/td[5]")).getText();
		System.out.println("subject = "+s);
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    driver.switchTo().frame(0);
		driver.findElement(By.xpath("//div[@id='rxRefillFrame']/div[2]/table/tbody/tr[4]/td/textarea")).clear();
	    driver.findElement(By.xpath("//div[@id='rxRefillFrame']/div[2]/table/tbody/tr[4]/td/textarea")).sendKeys("LabResultQuestionbody");
		driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
		assertEquals(closeAlertAndGetItsText(), "Lab Result Question sent.");
		
		driver.switchTo().defaultContent();
		String sCellValue = driver.findElement(By.xpath(".//*[@id='mailcontainer']/div[2]/table/tbody/tr/td/div/div/div/table/tbody/tr/td[1]")).getText();
		System.out.println("Lab Result Question: "+sCellValue);
		System.out.println("test");
		
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		String date = sdf.format(new Date());
		System.out.println(date); //10/15/2013
		
		driver.switchTo().parentFrame();
		driver.findElement(By.xpath("//div[@id='messagesModule']/a/font")).click();   // Messages
		driver.findElement(By.xpath("//ul[@id='mailtabs']/li[3]/a")).click();         // Sent
		driver.switchTo().frame("_ddajaxtabsiframe-mailcontainer");
		System.out.println("sent");
			
		String sCellDate1 = driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[1]/td[2]")).getText();
		System.out.println("Date: "+sCellDate1);
			
		String sCellSubject1 = driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[1]/td[3]")).getText();
		System.out.println(sCellSubject1);
		String refill ="Lab Result Question: ";
		LabResultMessage = refill+sCellValue;
			System.out.println(LabResultMessage);
			
			if(LabResultMessage.equals(sCellSubject1) && date.equals(sCellDate1)){
				System.out.println("Medication Refill sent and verified in Sent folder");
				test.log(LogStatus.PASS, "Medication Refill mail sent and verified in Sent folder");
			}else{
				System.out.println("data not matched");
				test.log(LogStatus.FAIL, "Medication Refill mail sent and verification failed in Sent folder");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyLabQuestionToSent1.png"), true);
			}
			driver.switchTo().defaultContent();
			if(driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a")).isDisplayed()){
					System.out.println("111111111111 - Success");
					WebElement element= driver.findElement(By.xpath("//ul[@id='mailtabs']/li/a"));
					WebDriverWait wait1 = new WebDriverWait(driver, timeoutInSeconds);
					wait1.until(ExpectedConditions.elementToBeClickable(element));
					driver.switchTo().defaultContent();
					driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();  
				}else{
					System.out.println("test case- failed");
				}
}



/*  
Test case 19
19. Inbox to Sent to Practice verification check */

@Test (priority = 18)
	public static void verifyInboxtoSentToPractice() throws InterruptedException, IOException{
	//	verifyInboxtoSent();
		Practicelogin();
		driver.findElement(By.xpath("//div[@id='secureMailModule']/a/font")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Inbox')]")).click();
		
		for (int i = 1; i <= 5; i++) {
			String PracticeInboxSubject= driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[" + i + "]/td[4]")).getText();    // path
			if(inboxsubject.contains(PracticeInboxSubject)){                  
				System.out.println("text Matched  " +PracticeInboxSubject );
				System.out.println("row = "+i);
				System.out.println("Patient portal inbox subject and Practice portal inbox subject matched");
				test.log(LogStatus.PASS, "Patient portal inbox subject and Practice portal inbox subject matched");
				break;
				}else{
					System.out.println("Patient portal inbox subject and Practice portal inbox subject matched");
					test.log(LogStatus.FAIL, "Patient portal inbox subject and Practice portal inbox subject matched");
					File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyInboxtoSentToPractice1.png"), true);
				}
}}




/*  
Test case 20
20. Compose to Sent to Practice verification check 

*/

@Test (priority = 19)
	public static void verifyComposetoSentToPractice() throws InterruptedException, IOException{
	//	verifyComposetoSent();
	//	Practicelogin();
		driver.findElement(By.xpath("//div[@id='secureMailModule']/a/font")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Inbox')]")).click();
		for (int k = 1; k <= 4; k++) {
			driver.findElement(By.xpath(".//*[@id='SHL_pagination']/a[" + k + "]")).click();
			for (int i = 1; i <= 5; i++) {
				String PracticeInboxSubject= driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[" + i + "]/td[4]")).getText();    // path		
				//System.out.println("Subject check "+PracticeInboxSubject);
				if(ComposeSubject.contains(PracticeInboxSubject)){
						System.out.println("Patient portal compose subject and Practice portal inbox subject matched");
						test.log(LogStatus.PASS, "Patient portal compose subject and Practice portal inbox subject matched");
						break;
					}else{
						System.out.println("Patient portal compose subject and Practice portal inbox subject matched");
						test.log(LogStatus.FAIL, "Patient portal compose subject and Practice portal inbox subject matched");
						File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
						FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyComposetoSentToPractice1.png"), true);
				}}}
}


/*  
Test case 21
21. MedicationRefill to Sent to Practice verification check 

*/

@Test (priority = 20)
	public static void verifyMedicationRefillToPractice() throws InterruptedException, IOException{
	//	verifyComposetoSent();
	//	Practicelogin();
		driver.findElement(By.xpath("//div[@id='secureMailModule']/a/font")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Inbox')]")).click();
		for (int k = 1; k <= 4; k++) {
			driver.findElement(By.xpath(".//*[@id='SHL_pagination']/a[" + k + "]")).click();
			for (int i = 1; i <= 5; i++) {
				String PracticeInboxSubject= driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[" + i + "]/td[4]")).getText();    // path		
				//System.out.println("Subject check "+PracticeInboxSubject);
				if(MedicationRefillMessage.contains(PracticeInboxSubject)){
						System.out.println("Patient portal compose subject and Practice portal inbox subject matched");
						test.log(LogStatus.PASS, "Patient portal compose subject and Practice portal inbox subject matched");
						break;
					}else{
						System.out.println("Patient portal compose subject and Practice portal inbox subject matched");
						test.log(LogStatus.FAIL, "Patient portal compose subject and Practice portal inbox subject matched");
						File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
						FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyMedicationRefillToPractice1.png"), true);
				}}}
}


/*  
Test case 22
22. MedicationQuestion to Sent to Practice verification check 
*/
@Test (priority = 21)
	public static void verifyMedicationQuestionToPractice() throws InterruptedException, IOException{
	//	verifyComposetoSent();
	//	Practicelogin();
		driver.findElement(By.xpath("//div[@id='secureMailModule']/a/font")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Inbox')]")).click();
		for (int k = 1; k <= 4; k++) {
			driver.findElement(By.xpath(".//*[@id='SHL_pagination']/a[" + k + "]")).click();
			for (int i = 1; i <= 5; i++) {
				String PracticeInboxSubject= driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[" + i + "]/td[4]")).getText();    // path		
				//System.out.println("Subject check "+PracticeInboxSubject);
				if(MedicationQuestionMessage.contains(PracticeInboxSubject)){
						System.out.println("Patient portal compose subject and Practice portal inbox subject matched");
						test.log(LogStatus.PASS, "Patient portal compose subject and Practice portal inbox subject matched");
						break;
					}else{
						System.out.println("Patient portal compose subject and Practice portal inbox subject matched");
						test.log(LogStatus.FAIL, "Patient portal compose subject and Practice portal inbox subject matched");
						File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
						FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyMedicationRefillToPractice1.png"), true);
				}}}
}


/*  
Test case 23
23. LabResultQuestion to Sent to Practice verification check 
*/
@Test (priority = 22)
	public static void verifyLabResultQuestionToPractice() throws InterruptedException, IOException{
	//	verifyComposetoSent();
	//	Practicelogin();
		driver.findElement(By.xpath("//div[@id='secureMailModule']/a/font")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Inbox')]")).click();
		for (int k = 1; k <= 4; k++) {
			driver.findElement(By.xpath(".//*[@id='SHL_pagination']/a[" + k + "]")).click();
			for (int i = 1; i <= 5; i++) {
				String PracticeInboxSubject= driver.findElement(By.xpath(".//*[@id='sortable']/tbody/tr[" + i + "]/td[4]")).getText();    // path		
				//System.out.println("Subject check "+PracticeInboxSubject);
				if(LabResultMessage.contains(PracticeInboxSubject)){
						System.out.println("Patient portal compose subject and Practice portal inbox subject matched");
						test.log(LogStatus.PASS, "Patient portal compose subject and Practice portal inbox subject matched");
						break;
					}else{
						System.out.println("Patient portal compose subject and Practice portal inbox subject matched");
						test.log(LogStatus.FAIL, "Patient portal compose subject and Practice portal inbox subject matched");
						File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
						FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyMedicationRefillToPractice1.png"), true);
				}}}
}

/*  
 Message module test cases
1. Hit Message --> it will show 4 sub tabs Inbox, Compose, Sent, Trash

2. Inbox 

3. Inbox to sent verify subject and body

4. inbox --> delete message (single and multiple)--> check trash
 
5. Trash -->  restore -->  inbox

Compose:
--> validation
--> verify on sent (to Sent verify subject and body)
--> verify on Practice setup
-->
6. Compose to Sent verify subject and body

7. Sent --> delete message (single and multiple)--> check trash 
8.    Trash -->  restore -->  Sent
	

9. Access Health info --> Patient summary --> My Medications --> Refill    =  insert some text and sent it.
	check sent with subject and body

10. Access Health info --> Patient summary --> My Medications --> Question    =  insert some text and sent it.
	check sent with subject and body

11. Access Health info --> Patient summary --> Lab Orders -->Question  =  insert some text and sent it.
	check sent with subject and body

Validation:
12. Access Health info --> Patient summary --> My Medications --> Refill    =  insert 2501 characters and check the validation

13. Access Health info --> Patient summary --> My Medications --> Question    =  insert 2501 characters and check the validation	

14. Access Health info --> Patient summary --> Lab Order --> Question    =  insert 2501 characters and check the validation



Practice side verification

14. do step 2(Inbox to sent verify subject and body) --> Practice login --> Secure Mail --> Inbox --> Verify Subject and Body

15. do step 5(Compose to Sent verify) --> Practice login --> Secure Mail --> Inbox --> Verify Subject and Body

16. do step 8(Health info -->Refill) --> Practice login --> Secure Mail --> Inbox --> Verify Subject and Body

17. do step 9(Health info -->question) --> Practice login --> Secure Mail --> Inbox --> Verify Subject and Body

18. do step 10(Health info -->Laborder -->Question) --> Practice login --> Secure Mail --> Inbox --> Verify Subject and Body

19. Practice login --> Secure Mail --> Inbox --> Reply to Patient portal 
     Check patient portal login --> Messages --> Inbox  --> Verify subject and body
 
 
 * */





@AfterMethod
public void afterMethod() {
	 extent.endTest(test);
//	 driver.close();
	 }
@AfterSuite
public void aftetsuite(){
	  
	//  driver.close();
	  test.log(LogStatus.PASS, "Browser closed successfully");
	  extent.flush();
	  extent.close();
}
}
