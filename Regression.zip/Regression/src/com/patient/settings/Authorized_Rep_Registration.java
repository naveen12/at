package com.patient.settings;

import java.io.File;
import java.lang.reflect.Method;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.Info;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class Authorized_Rep_Registration extends Info {
@BeforeSuite
	public void beforesuite(){
	  extent = new ExtentReports("D://Automation_Testing//EclipseProjects//Regression//Result//Authorized_Rep_Registration_report.html",true);
	  extent.loadConfig(new File("D://Automation_Testing//EclipseProjects//Regression//extent-config.xml"));
	}
@BeforeMethod
	public void beforeMethod(Method method) {
		test= extent.startTest((this.getClass().getSimpleName() + " :: " + method.getName()), method.getName());
		test.assignAuthor("Naveen");
		test.assignCategory("Authorized_Rep_Registration test report");
	}

@Test (priority = 0)	
	public static void Ar_Correct() throws InterruptedException{
		login();
		driver.switchTo().defaultContent();
		System.out.println("**************Authorized Representative Ar_Correct**************");
		driver.findElement(By.xpath("//div[@id='headerx']/div/div/a/div")).click();
		System.out.println("1............Entered Settings module");
		driver.findElement(By.xpath("//a[contains(@href, 'GetPortalARDetails.do')]")).click();
		System.out.println("2............AR module");
		driver.findElement(By.xpath("//input[@id='firstnameID']")).sendKeys(ar_firstname);
		driver.findElement(By.xpath("//input[@id='lastnameID']")).sendKeys(ar_lastname);
		driver.findElement(By.xpath(".//*[@id='phoneID']")).sendKeys(ar_phone);
		driver.findElement(By.xpath("//input[@id='emailID']")).sendKeys(ar_email);
		driver.findElement(By.xpath("//a[@id='saveButton']/span")).click();	
		
		if(driver.findElement(By.xpath(".//*[@id='error']/strong[2]")).getText().equalsIgnoreCase("Authorized Representative invitation sent successfully.")){
			System.out.println("Authorized Representative record insert - Success");
			test.log(LogStatus.PASS, "test case = Authorized Representative record insert - working fine");			
		}else{
				System.out.println("Authorized Representative record insert - failed");
				test.log(LogStatus.FAIL, "Authorized Representative record insert - failed");
			}
	}
	
@Test (priority = 1)	
	public static void ARVerification(){
		driver.get(ar_register_url);
		System.out.println("Entered Patient match page");
		driver.findElement(By.xpath("//input[@id='firstName']")).sendKeys(ar_firstname);
		driver.findElement(By.xpath("//input[@id='lastName']")).sendKeys(ar_lastname);
		driver.findElement(By.xpath(".//*[@id='phoneNumber']")).sendKeys(ar_phone);
		driver.findElement(By.xpath("//a/span")).click();
		
		if(driver.findElement(By.xpath("//input[@id='birthdayMonth']")).isDisplayed()){
			System.out.println("Authorized Representative - Success");
			test.log(LogStatus.PASS, "Authorized Representative module showing - Success");
			
			}else{
				System.out.println("Authorized Representative module- failed");
				test.log(LogStatus.FAIL, "Authorized Representative module- failed");
			}
	}
@Test (priority = 2)	
	public static void UserSetup(){
		
		System.out.println("Entered in Usersetup module");
		driver.findElement(By.xpath("//input[@id='birthdayMonth']")).sendKeys(birthdayMonth);
		driver.findElement(By.xpath("//input[@id='birthdayDate']")).sendKeys(birthdayDate);
		driver.findElement(By.xpath("//input[@id='birthdayYear']")).sendKeys(birthdayYear);
		//input[@id='password']
		//input[@name='confirmPassword']
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(create_Password);
		driver.findElement(By.xpath("//input[@name='confirmPassword']")).sendKeys(create_confirm_Password);
		Select dropdown1 = new Select(driver.findElement(By.id("selectedQuestion")));
	    dropdown1.selectByIndex(0);	   
		driver.findElement(By.xpath("//input[@id='securityAnswer']")).sendKeys("surat");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a/span")).click();
		System.out.println("Next button");
		
		if(driver.findElement(By.xpath("//input[@id='Agree']")).isDisplayed()){
			System.out.println("Usersetup module- completed");
			test.log(LogStatus.PASS, "test case = UserSetup process completed");
			test.log(LogStatus.PASS, "test case passed successfully");
			
			}else{
				System.out.println("Usersetup module- failed");
				test.log(LogStatus.FAIL, "Details are not matched");
			}
}
@Test (priority = 3)
	public static void UserAgreement(){
		System.out.println("UserAgreement module- stated");
		driver.findElement(By.xpath("//input[@id='Agree']")).click();
		driver.findElement(By.xpath("//input[@id='IUnderstand']")).click();
		driver.findElement(By.xpath("//a/span")).click();
		System.out.println("UserAgreement module- completed");
		
		if(driver.findElement(By.xpath("//a/span")).isDisplayed()){
			System.out.println("UserAgreement module- completed");
			test.log(LogStatus.PASS, "test case = UserAgreement process completed");
			test.log(LogStatus.PASS, "test case passed successfully");
			
			}else{
				System.out.println("UserAgreement module- failed");
				test.log(LogStatus.FAIL, "UserAgreement module- failed");
			}
	}
@Test (priority = 4)
	public static void EmailVerification(){
		System.out.println("E-mail Verification- starting............");
		driver.findElement(By.xpath("//a/span")).click();
		System.out.println("E-mail Verification - completed..................");
		driver.close();
	}

	@AfterMethod
	public void afterMethod() {
		 extent.endTest(test);
		 
		 }
	@AfterSuite
	public void aftetsuite(){
		  
		//  driver.close();
		  test.log(LogStatus.PASS, "Browser closed successfully");
		  extent.flush();
		  extent.close();
	}	
	
	
}
