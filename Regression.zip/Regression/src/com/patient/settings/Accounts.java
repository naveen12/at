package com.patient.settings;

/// Normal user functionality

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.lang.reflect.Method;

import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.Info;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class Accounts extends Info {
	
	/* Setting test suite order is  1. Notification, 2. Billing, 3.Profile, 4. Authorized_Rep, 5. Accounts  */
@BeforeSuite
	public void beforesuite(){
	  extent = new ExtentReports("D://Automation_Testing//EclipseProjects//Regression//Result//Settings_account_report1.html",true);
	  extent.loadConfig(new File("D://Automation_Testing//EclipseProjects//Regression//extent-config.xml"));
	}
@BeforeMethod
	public void beforeMethod(Method method) {
		test= extent.startTest((this.getClass().getSimpleName() + " :: " + method.getName()), method.getName());
		test.assignAuthor("Naveen");
		test.assignCategory("Messages test report");
	}
@Test (priority = 0)
	public void Account() throws InterruptedException{
	//	login();
		driver.switchTo().defaultContent();
		System.out.println("**************PasswordChangeModule**************");
		driver.findElement(By.xpath("//div[@id='headerx']/div/div/a/div")).click();
		System.out.println("1............Entered Settings module");
		driver.findElement(By.xpath("//a[contains(text(),'Account')]")).click();
		System.out.println("2............Entered Account module");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(Password);
		System.out.println("3............Entered Password");
		test.log(LogStatus.PASS, "Entered Password change module");
		driver.findElement(By.xpath("//div[@id='Layoutbody']/table/tbody/tr[2]/td/form/fieldset/table/tbody/tr[3]/td/div/table/tbody/tr/td[2]/div/a/span")).click(); //Next button
		System.out.println("4............Password change module");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(change_Password);
		System.out.println("5............Entered Password");
		driver.findElement(By.xpath("//input[@name='confirmPassword']")).sendKeys(change_confirm_Password);
		System.out.println("6............Entered confirmPassword");
		driver.findElement(By.xpath("//div[@id='Layoutbody']/table/tbody/tr[3]/td/div/table/tbody/tr/td[2]/div/a/span")).click();  // Save button
		System.out.println("7............Password changed successfully");		
		test.log(LogStatus.PASS, "Password changed successfully");
	//	assertEquals(closeAlertAndGetItsText(), "Your account password has been updated.");
	}
@Test (priority = 1)
	public void PasswordChangeReuse(){
		driver.switchTo().defaultContent();
		System.out.println("***************Destructive test case ********PasswordChangeReuse**************");	
		driver.findElement(By.xpath("//div[@id='headerx']/div/div/a/div")).click();
		System.out.println("1............Entered Settings module");
		driver.findElement(By.xpath("//a[contains(text(),'Account')]")).click();
		System.out.println("2............Entered Account module");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(Password); // this functionality working wrong
		System.out.println("3............Entered Old Password");
		test.log(LogStatus.PASS, "Entered Password change module");
		driver.findElement(By.xpath("//div[@id='Layoutbody']/table/tbody/tr[2]/td/form/fieldset/table/tbody/tr[3]/td/div/table/tbody/tr/td[2]/div/a/span")).click(); //Next button
		System.out.println("4............Password change module");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(Password);
		System.out.println("5............Entered Password");
		driver.findElement(By.xpath("//input[@name='confirmPassword']")).sendKeys(Password);
		driver.findElement(By.xpath("//div[@id='Layoutbody']/table/tbody/tr[3]/td/div/table/tbody/tr/td[2]/div/a/span")).click();  // Save button
		if(driver.findElement(By.xpath(".//*[@id='hide']/div[1]/strong")).getText().equalsIgnoreCase("New password must be different than current password.")){
			System.out.println("test case passed successfully");
			test.log(LogStatus.PASS, "test case passed successfully");
		}else{
			System.out.println("test case failed");
			test.log(LogStatus.FAIL, "test case failed");
		}
}
@Test (priority = 2)
	public void WrongPasswordCheck() throws Exception{
		driver.switchTo().defaultContent();
		System.out.println("***************Destructive test case ********WrongPasswordCheck**************");	
		driver.findElement(By.xpath("//div[@id='headerx']/div/div/a/div")).click();
		System.out.println("1............Entered Settings module");
		driver.findElement(By.xpath("//a[contains(text(),'Account')]")).click();
		System.out.println("2............Entered Account module");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(change_Password); // this functionality working wrong
		System.out.println("3............Entered New changed Password ");
		test.log(LogStatus.PASS, "Entered Password change module");
		driver.findElement(By.xpath("//div[@id='Layoutbody']/table/tbody/tr[2]/td/form/fieldset/table/tbody/tr[3]/td/div/table/tbody/tr/td[2]/div/a/span")).click(); //Next button
		if(driver.findElement(By.xpath(".//*[@id='clearFields']/ul/li")).getText().equalsIgnoreCase("Verification information is invalid, re-enter your information.")){
			System.out.println("test case passed successfully");
			test.log(LogStatus.PASS, "test case passed successfully");
		}else{
			System.out.println("test case failed");
			test.log(LogStatus.FAIL, "test case failed");
		}
		Logout();
}
//@Test (priority = 3)
	// logout removed



@AfterMethod
public void afterMethod() {
	 extent.endTest(test);
}
@AfterSuite
public void aftetsuite(){
	  
	//  driver.close();
	  test.log(LogStatus.PASS, "Browser closed successfully");
	  extent.flush();
	  extent.close();
}
}
