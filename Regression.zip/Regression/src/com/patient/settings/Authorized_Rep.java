
package com.patient.settings;

import java.io.File;
import java.lang.reflect.Method;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.Info;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

/**
 * Before starting this test case execution please delete the AR in portal.
 *
 */
public class Authorized_Rep extends Info {
	
	/* Setting test suite order is  1. Notification, 2. Billing, 3.Profile, 4. Authorized_Rep, 5. Accounts  */
@BeforeSuite
	public void beforesuite(){
	  extent = new ExtentReports("D://Automation_Testing//EclipseProjects//Regression//Result//Authorized_Representative_report.html",true);
	  extent.loadConfig(new File("D://Automation_Testing//EclipseProjects//Regression//extent-config.xml"));
	}
@BeforeMethod
	public void beforeMethod(Method method) {
		test= extent.startTest((this.getClass().getSimpleName() + " :: " + method.getName()), method.getName());
		test.assignAuthor("Naveen");
		test.assignCategory("Authorized_Representative test report");
	}
@Test (priority = 0)
	public static void ArTab() throws InterruptedException{
	//	login();
		driver.switchTo().defaultContent();
		System.out.println("**************Authorized Representative Tab**************");
		driver.findElement(By.xpath("//div[@id='headerx']/div/div/a/div")).click();
		System.out.println("1............Entered Settings module");
		driver.findElement(By.xpath("//a[contains(@href, 'GetPortalARDetails.do')]")).click();
		System.out.println("2............AR module");
	
		if(driver.findElement(By.xpath("//tr[@id='emrCntID']/td/input")).isDisplayed()){
			System.out.println("Authorized Representative - Success");
			test.log(LogStatus.PASS, "Authorized Representative module showing - Success");
			
			}else{
				System.out.println("Authorized Representative module- failed");
				test.log(LogStatus.FAIL, "Authorized Representative module- failed");
			}	
	}
@Test (priority = 1)	
	public static void Ar_Validation() throws InterruptedException{
	//	login();
		driver.switchTo().defaultContent();
		System.out.println("**************Authorized Representative Ar_validation**************");
		driver.findElement(By.xpath("//div[@id='headerx']/div/div/a/div")).click();
		System.out.println("1............Entered Settings module");
		driver.findElement(By.xpath("//a[contains(@href, 'GetPortalARDetails.do')]")).click();
		System.out.println("2............AR module");
		driver.findElement(By.xpath("//a[@id='saveButton']/span")).click();	
						
		if(driver.findElement(By.xpath(".//*[@id='error']/strong/ul/li[1]")).getText().equalsIgnoreCase("Authorized Representative first name is required.")){
			System.out.println("Authorized Representative validation check - Success");
			test.log(LogStatus.PASS, "test case = Authorized Representative validation check - working fine");			
			}else{
				System.out.println("Authorized Representative validation check - failed");
				test.log(LogStatus.FAIL, "Authorized Representative validation check - failed");
			}	
	}
@Test (priority = 2)	
	public static void Ar_Incorrect() throws InterruptedException{
	//	login();
		driver.switchTo().defaultContent();
		System.out.println("**************Authorized Representative Ar_Incorrect**************");
		driver.findElement(By.xpath("//div[@id='headerx']/div/div/a/div")).click();
		System.out.println("1............Entered Settings module");
		driver.findElement(By.xpath("//a[contains(@href, 'GetPortalARDetails.do')]")).click();
		System.out.println("2............AR module");
		driver.findElement(By.xpath("//input[@id='firstnameID']")).sendKeys(ar_firstname);
		driver.findElement(By.xpath("//input[@id='lastnameID']")).sendKeys(ar_lastname);
		driver.findElement(By.xpath(".//*[@id='phoneID']")).sendKeys(ar_phone);
		driver.findElement(By.xpath("//input[@id='emailID']")).sendKeys("testar.com");
		driver.findElement(By.xpath("//a[@id='saveButton']/span")).click();
			
		if(driver.findElement(By.xpath(".//*[@id='error']/strong/ul/li")).getText().equalsIgnoreCase("E-mail address is invalid.")){
			System.out.println("Authorized Representative validation check - Success");
			test.log(LogStatus.PASS, "test case = Authorized Representative validation check - working fine");			
			}else{
				System.out.println("Authorized Representative validation check - failed");
				test.log(LogStatus.FAIL, "Authorized Representative validation check - failed");
			}
		
	}
@Test (priority = 3)
public static void Ar_Correct() throws InterruptedException{
//	login();
	driver.switchTo().defaultContent();
	System.out.println("**************Authorized Representative Ar_Correct**************");
	driver.findElement(By.xpath("//div[@id='headerx']/div/div/a/div")).click();
	System.out.println("1............Entered Settings module");
	driver.findElement(By.xpath("//a[contains(@href, 'GetPortalARDetails.do')]")).click();
	System.out.println("2............AR module");
	driver.findElement(By.xpath("//input[@id='firstnameID']")).sendKeys(ar_firstname);
	driver.findElement(By.xpath("//input[@id='lastnameID']")).sendKeys(ar_lastname);
	driver.findElement(By.xpath(".//*[@id='phoneID']")).sendKeys(ar_phone);
	driver.findElement(By.xpath("//input[@id='emailID']")).sendKeys(ar_email);
	driver.findElement(By.xpath("//a[@id='saveButton']/span")).click();	
	
	if(driver.findElement(By.xpath(".//*[@id='error']/strong[2]")).getText().equalsIgnoreCase("Authorized Representative invitation sent successfully.")){
		System.out.println("Authorized Representative record insert - Success");
		test.log(LogStatus.PASS, "test case = Authorized Representative record insert - working fine");			
	}else{
			System.out.println("Authorized Representative record insert - failed");
			test.log(LogStatus.FAIL, "Authorized Representative record insert - failed");
		}
}
@Test (priority = 4)
	public static void Ar_Delete() throws InterruptedException{
	//	login();
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='headerx']/div/div/a/div")).click();
		System.out.println("1............Entered Settings module");
		driver.findElement(By.xpath("//a[contains(@href, 'GetPortalARDetails.do')]")).click();
		System.out.println("2............AR module");
		System.out.println("**************Authorized Representative Ar_delete**************");
		driver.findElement(By.xpath("//a[@id='deleteButton']/span")).click();
		System.out.println("successfully deleted data");
			if(driver.findElement(By.xpath(".//*[@id='error']/strong[2]")).getText().equalsIgnoreCase("Authorized Representative deleted successfully.")){		
				System.out.println("Authorized Representative Delete check - Success");
				test.log(LogStatus.PASS, "test case = Authorized Representative Delete check - working fine");			
			}else{
					System.out.println("Authorized Representative Delete check - failed");
					test.log(LogStatus.FAIL, "Authorized Representative Delete check - failed");
				}
		}
	
	@AfterMethod
	public void afterMethod() {
		 extent.endTest(test);
	//	 driver.close();
		 }
	@AfterSuite
	public void aftetsuite(){
		  
		//  driver.close();
		  test.log(LogStatus.PASS, "Browser closed successfully");
		  extent.flush();
		  extent.close();
	}
	
}
