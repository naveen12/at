package com.patient.settings;

import java.io.File;
import java.lang.reflect.Method;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.Info;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class Profile extends Info {
	
	/* Setting test suite order is  1. Notification, 2. Billing, 3.Profile, 4. Authorized_Rep, 5. Accounts  */	
	@BeforeSuite
	public void beforesuite(){
	  extent = new ExtentReports("D://Automation_Testing//EclipseProjects//Regression//Result//Settings_Profile_report1.html",true);
	  extent.loadConfig(new File("D://Automation_Testing//EclipseProjects//Regression//extent-config.xml"));
	}
@BeforeMethod
	public void beforeMethod(Method method) {
		test= extent.startTest((this.getClass().getSimpleName() + " :: " + method.getName()), method.getName());
		test.assignAuthor("Naveen");
		test.assignCategory("Messages test report");
	}
@Test (priority = 0)
	public static void validateAddress() throws Exception{
	//	login();
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='headerx']/div/div/a/div")).click();
		driver.findElement(By.xpath("//ul[@id='mailtabs']/li[2]/a")).click();
		driver.findElement(By.xpath("//input[@id='currentAddressLine1']")).clear();
		driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
		if((driver.findElement(By.xpath(".//*[@id='error']/strong/ul/li")).getText().equalsIgnoreCase("Current Address line 1 is required.")))
		{
			System.out.println("Blank Address1 validation working on Profile Page");
			test.log(LogStatus.PASS, "Blank Address1 validation working on Profile Page");
			
		}else{
			System.out.println("Blank Address1 validation not working on Profile Page");
			test.log(LogStatus.FAIL, "Blank Address1 validation not working on Profile Page");
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\validateAddress1.png"), true);
		}
	}

@Test (priority = 1)
	public static void validatecityzip() throws Exception{
		driver.findElement(By.xpath("//input[@id='currentAddressZip']")).clear();
	//	driver.findElement(By.xpath("//input[@id='currentAddressZip']")).sendKeys("45454545");
		
		driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
		if((driver.findElement(By.xpath(".//*[@id='error']/strong/ul/li")).getText().equalsIgnoreCase("Current Address zip code is required.")))
		{
			System.out.println("Blank zip validation working on Profile Page");
			test.log(LogStatus.PASS, "Blank zip validation working on Profile Page");
			
		}else{
			System.out.println("Blank zip validation not working on Profile Page");
			test.log(LogStatus.FAIL, "Blank zip validation not working on Profile Page");
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\validatecityzip1.png"), true);
		}
	}

@Test (priority = 2)
	public static void validateEmergencyContactName() throws Exception{
		
		driver.findElement(By.xpath("//input[@id='emergencyContactName']")).clear();
				
		driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
		if((driver.findElement(By.xpath(".//*[@id='error']/strong/ul/li")).getText().equalsIgnoreCase("Emergency contact name is required.")))
		{
			System.out.println("Blank emergencyContactName validation working on Profile Page");
			test.log(LogStatus.PASS, "Blank emergencyContactName validation working on Profile Page");
			
		}else{
			System.out.println("Blank emergencyContactName validation not working on Profile Page");
			test.log(LogStatus.FAIL, "Blank emergencyContactName validation not working on Profile Page");
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\validateEmergencyContactName1.png"), true);
		}
	}


@Test (priority = 3)
	public static void validatePhone() throws Exception{
		driver.findElement(By.xpath(".//*[@id='emergencyPhone']")).clear();
				
		driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
		if((driver.findElement(By.xpath(".//*[@id='error']/strong/ul/li")).getText().equalsIgnoreCase("Emergency Contact cell phone number is required.")))
		{
			System.out.println("Blank Emergency Contact cell phone number validation working on Profile Page");
			test.log(LogStatus.PASS, "Blank Emergency Contact cell phone number validation working on Profile Page");
			
		}else{
			System.out.println("Blank Emergency Contact cell phone number validation not working on Profile Page");
			test.log(LogStatus.FAIL, "Blank Emergency Contact cell phone number validation not working on Profile Page");
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\validatePhone1.png"), true);
		}
	}

@Test (priority = 4)
	public static void validateEmail() throws Exception{
		driver.findElement(By.xpath(".//*[@id='emergencyEmail2']")).clear();
				
		driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
		if((driver.findElement(By.xpath(".//*[@id='error']/strong/ul/li")).getText().equalsIgnoreCase("Emergency email is required.")))
		{
			System.out.println("Blank Email validation working on Profile Page");
			test.log(LogStatus.PASS, "Blank Email validation working on Profile Page");
			
		}else{
			System.out.println("Blank Email validation not working on Profile Page");
			test.log(LogStatus.FAIL, "Blank Email validation not working on Profile Page");
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\validateEmail1.png"), true);
		}
	}
@Test (priority = 5)
	public static void validateAll() throws Exception{
		driver.findElement(By.xpath("//input[@id='currentAddressLine1']")).clear();
		driver.findElement(By.xpath("//input[@id='currentAddressZip']")).clear();
		driver.findElement(By.xpath("//input[@id='emergencyContactName']")).clear();
		driver.findElement(By.xpath(".//*[@id='emergencyPhone']")).clear();
		driver.findElement(By.xpath(".//*[@id='emergencyEmail2']")).clear();
				
		driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
		if((driver.findElement(By.xpath(".//*[@id='error']/strong/ul/li")).getText().equalsIgnoreCase("Current Address line 1 is required.")) && 
				(driver.findElement(By.xpath(".//*[@id='error']/strong/ul/li")).getText().equalsIgnoreCase("Current Address zip code is required."))&& 
				(driver.findElement(By.xpath(".//*[@id='error']/strong/ul/li")).getText().equalsIgnoreCase("Emergency contact name is required.")) && 
				(driver.findElement(By.xpath(".//*[@id='error']/strong/ul/li")).getText().equalsIgnoreCase("Emergency Contact cell phone number is required."))&& 
				(driver.findElement(By.xpath(".//*[@id='error']/strong/ul/li")).getText().equalsIgnoreCase("Emergency email is required.")))
		{
			System.out.println("All Mandatory fields are Blank and validation is working on Profile Page");
			test.log(LogStatus.PASS, "All Mandatory fields are Blank and validation is working on Profile Page");
			
		}else{
			System.out.println("All Mandatory fields are not Blank and validation is not working on Profile Page");
			test.log(LogStatus.FAIL, "All Mandatory fields are not Blank and validation is not working on Profile Page");
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\validateAll1.png"), true);
		}
	}


@Test (priority = 6)
	public static void ProfileFunctional() throws Exception{
		driver.findElement(By.xpath("//input[@id='currentAddressLine1']")).clear();
		driver.findElement(By.xpath("//input[@id='currentAddressLine1']")).sendKeys(Address1);
		driver.findElement(By.xpath("//input[@id='currentAddressLine2']")).clear();
		driver.findElement(By.xpath("//input[@id='currentAddressLine2']")).sendKeys(Address2);
		driver.findElement(By.xpath("//input[@id='currentAddressZip']")).clear();
		driver.findElement(By.xpath("//input[@id='currentAddressZip']")).sendKeys(cityzip);
		driver.findElement(By.xpath(".//*[@id='currentAddressHomePhone']")).clear();
		driver.findElement(By.xpath(".//*[@id='currentAddressHomePhone']")).sendKeys(homephone);
		driver.findElement(By.xpath(".//*[@id='currentAddressOfficePhone']")).clear();
		driver.findElement(By.xpath(".//*[@id='currentAddressOfficePhone']")).sendKeys(workphone);
		driver.findElement(By.xpath(".//*[@id='currentAddresscellPhone']")).clear();
		driver.findElement(By.xpath(".//*[@id='currentAddresscellPhone']")).sendKeys(cellphone);
		//driver.findElement(By.xpath(".//*[@id='currentAddressEmail1']")).clear();
		//driver.findElement(By.xpath(".//*[@id='currentAddressEmail1']")).sendKeys(workemail);
		driver.findElement(By.xpath("//input[@id='emergencyContactName']")).clear();
		driver.findElement(By.xpath("//input[@id='emergencyContactName']")).sendKeys(EmergencyName);
		driver.findElement(By.xpath(".//*[@id='emergencyContactRelation']")).clear();
		driver.findElement(By.xpath(".//*[@id='emergencyContactRelation']")).sendKeys(EmergencyRelationship);
		driver.findElement(By.xpath(".//*[@id='emergencyPhone']")).clear();
		driver.findElement(By.xpath(".//*[@id='emergencyPhone']")).sendKeys(EmergencyPhone);
		driver.findElement(By.xpath("//input[@id='SMS']")).click();
		driver.findElement(By.xpath(".//*[@id='emergencyEmail2']")).clear();
		driver.findElement(By.xpath(".//*[@id='emergencyEmail2']")).sendKeys(EmergencyEmail);
		driver.findElement(By.cssSelector("a.NWebButton3NewPrimary > span")).click();
		
		if((driver.findElement(By.xpath(".//*[@id='hide']/div[1]/strong")).getText().equalsIgnoreCase("Contact information successfully updated")))
		{
			System.out.println("Inserted data in all fields on Profile Page and it working fine");
			test.log(LogStatus.PASS, "Inserted data in all fields on Profile Page and it working fine");
			
		}else{
			System.out.println("Data insertion issue on Profile Page");
			test.log(LogStatus.FAIL, "Data insertion issue on Profile Page");
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\ProfileFunctional1.png"), true);
		}
	}





@AfterMethod
public void afterMethod() {
	 extent.endTest(test);
}
@AfterSuite
public void aftetsuite(){
	  
	  driver.close();
	  test.log(LogStatus.PASS, "Browser closed successfully");
	  extent.flush();
	  extent.close();
}
}
