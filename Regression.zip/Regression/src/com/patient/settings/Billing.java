package com.patient.settings;

import java.io.File;
import java.lang.reflect.Method;

import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.Info;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class Billing extends Info{
	
	/* Setting test suite order is  1. Notification, 2. Billing, 3.Profile, 4. Authorized_Rep, 5. Accounts  */
	@BeforeSuite
	public void beforesuite(){
	  extent = new ExtentReports("D://Automation_Testing//EclipseProjects//Regression//Result//Settings_Billing_report1.html",true);
	  extent.loadConfig(new File("D://Automation_Testing//EclipseProjects//Regression//extent-config.xml"));
	}
@BeforeMethod
	public void beforeMethod(Method method) {
		test= extent.startTest((this.getClass().getSimpleName() + " :: " + method.getName()), method.getName());
		test.assignAuthor("Naveen");
		test.assignCategory("Messages test report");
	}
@Test (priority = 0)
	public static void BillingVerificaiton() throws InterruptedException{
	//	login();
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='headerx']/div/div/a/div")).click();    //setting
		driver.findElement(By.xpath("//ul[@id='mailtabs']/li[5]/a")).click();   //
		if(driver.findElement(By.xpath("//input[@id='portalStatements']")).isSelected()){
			
			System.out.println("Statement is selected");
			test.log(LogStatus.PASS, "Statement is selected");
			
		}else{
			System.out.println("Statement is not selected");
			test.log(LogStatus.PASS, "Statement is not selected");
		}
		
	}

  @Test (priority = 1)
	public static void BillingFunctional() throws InterruptedException{

		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='headerx']/div/div/a/div")).click();    //setting
		driver.findElement(By.xpath("//ul[@id='mailtabs']/li[5]/a")).click();   //
		if(!driver.findElement(By.xpath("//input[@id='portalStatements']")).isSelected()){
			driver.findElement(By.xpath("//input[@id='portalStatements']")).click();
			System.out.println("Check box selected");
			test.log(LogStatus.PASS, "All Notificaitons are not selected, one of Notification missed");
		}
		driver.findElement(By.xpath("//div[@id='Layoutbody']/form/div/table/tbody/tr[2]/td/table/tbody/tr/td/div/div/table/tbody/tr[3]/td/table/tbody/tr/td/div/a/span")).click();
	}
  @Test (priority = 2)
  public static void BillingDestructive() throws InterruptedException{
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='headerx']/div/div/a/div")).click();    //setting
		driver.findElement(By.xpath("//ul[@id='mailtabs']/li[5]/a")).click();   //
		if(driver.findElement(By.xpath("//input[@id='portalStatements']")).isSelected()){
			System.out.println("Check box selected   destructive");
			driver.findElement(By.xpath("//input[@id='portalStatements']")).click();
			System.out.println("Check box unselected   destructive");
			test.log(LogStatus.PASS, "All Notificaitons are not selected, one of Notification missed");

		}
		driver.findElement(By.xpath("//div[@id='Layoutbody']/form/div/table/tbody/tr[2]/td/table/tbody/tr/td/div/div/table/tbody/tr[3]/td/table/tbody/tr/td/div/a/span")).click();
	}


@AfterMethod
public void afterMethod() {
	 extent.endTest(test);
}
@AfterSuite
public void aftetsuite(){
	  
	  driver.close();
	  test.log(LogStatus.PASS, "Browser closed successfully");
	  extent.flush();
	  extent.close();
}
}
