package com.patient.appointment;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertSame;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.Info;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class AppointmentDestructive extends Info{
@BeforeSuite
	public void beforesuite(){
	  extent = new ExtentReports("D://Automation_Testing//EclipseProjects//Regression//Result//AppointmentDestructive_report.html",true);
	  extent.loadConfig(new File("D://Automation_Testing//EclipseProjects//Regression//extent-config.xml"));
	}
@BeforeMethod
	public void beforeMethod(Method method) {
		test= extent.startTest((this.getClass().getSimpleName() + " :: " + method.getName()), method.getName());
		test.assignAuthor("Naveen");
		test.assignCategory("AppointmentDestructive test report");
	}

/*              6.2.1  Test to verify Appointment Location/Provider/Reason blank.
                 6.2.1.1  Test Steps
Hit link of Portal side, Enter User Name and Password >> Login >> Appointments >> Keep Location, Provider and Reason blank >> Search
                 6.2.1.2  Expected Result
It should display validation message �Please select Appointment Location�  */
@Test (priority = 0)
	public static void AppointmentValidation() throws InterruptedException{
		login();
		System.out.println("total blank");
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	//	Select dropdown1 = new Select(driver.findElement(By.id("Location")));
	//	dropdown1.selectByIndex(1);
		new Select(driver.findElement(By.id("Location"))).selectByVisibleText("Please Select Location");
		driver.findElement(By.cssSelector("#searchButton > span")).click();
		System.out.println("search");
		Assert.assertTrue(true, "Please Select Appointment Location");
		Assert.assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Location");
		System.out.println("Validation working on blank Location");
		test.log(LogStatus.PASS, "Validation working on blank Location");		
	}
/*              6.2.2  Test to verify Appointment Provider/Location blank.
                 6.2.2.1  Test Steps
Hit link of Portal side, Enter User Name and Password >> Login >> Appointments >> Provide Location, Keep Provider and Appointment Reason blank >> Search
                 6.2.2.2  Expected Result
It should display validation message �Please select Appointment Provider�.  */
@Test (priority = 1)
	public static void AppointmentValidation1() throws InterruptedException{
	//	login();
		System.out.println("*******location selected*******");
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptlocation);
		System.out.println("location selected");
		
		Thread.sleep(100);
		new Select(driver.findElement(By.id("Provider"))).selectByValue("0");
	//	.selectByVisibleText("Please Select Provider");
	//	new Select(driver.findElement(By.id("Provider"))).selectByVisibleText("Please Select Provider");
		System.out.println("Provider selected");
		driver.findElement(By.cssSelector("#searchButton > span")).click();
		System.out.println("search");
		Assert.assertTrue(true, "Please Select Appointment Provider");
		Assert.assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Provider");
		System.out.println("Validation working on blank provider");
		test.log(LogStatus.PASS, "Validation working on blank provider");		
	}	
/*             6.2.3  Test to verify Appointment Reason blank.
                 6.2.3.1  Test Steps
Hit link of Portal side, Enter User Name and Password >> Login >> Appointments >> Provide Location, Provider and Keep Appointment Reason blank >>> Search
                 6.2.3.2  Expected Result
It should display validation message �Please select Appointment Reason�.*/
@Test (priority = 2)
	public static void AppointmentValidation2() throws InterruptedException{
	//	login();
		System.out.println("*******provider selected*******");
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptlocation);
		System.out.println("location selected");
		new Select(driver.findElement(By.id("Provider"))).selectByVisibleText(apptprovider);
		System.out.println("Provider selected");
		driver.findElement(By.cssSelector("#searchButton > span")).click();
		System.out.println("search");
		Assert.assertTrue(true, "Please Select Appointment Reason");
		Assert.assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Reason");
		System.out.println("Validation working on blank Reason");
		test.log(LogStatus.PASS, "Validation working on blank Reason");		
	}	

/*             6.2.4  Test to verify Appointment from Date blank.
                 6.2.4.1  Test Steps
Hit link of Portal side, Enter User Name and Password >> Login >> Appointments >> Provide Reason, Provider and Location >> Select Advanced Search �On� >> Keep Select date: From blank >> search
                 6.2.4.2  Expected Result
It should display validation message �Please select: from date�.*/
@Test (priority = 3)
	public static void blankFromDate() throws InterruptedException{
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptlocation);
		new Select(driver.findElement(By.id("Provider"))).selectByVisibleText(apptprovider);
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
		driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
		assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Reason");
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText("06March2017");
	    System.out.println("appt search");
	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    driver.findElement(By.cssSelector("#searchButton > span")).click();
	    driver.findElement(By.xpath("//input[@id='advanceSearch']")).click();
	    driver.findElement(By.name("monthFrom")).clear();
	    driver.findElement(By.name("monthFrom")).sendKeys("00");
	    driver.findElement(By.name("dateFrom")).clear();
	    driver.findElement(By.name("dateFrom")).sendKeys("0");
	    driver.findElement(By.cssSelector("#searchButton > span")).click();
		System.out.println("search");
		Assert.assertTrue(true, "Please select: From Date");
		Assert.assertEquals(closeAlertAndGetItsText(), "Please select: From Date");
		System.out.println("popup closed");
		test.log(LogStatus.PASS, "Validation working on blank From Date");
	}
	/*             6.2.5  Test to verify Appointment �To Date� blank.
                 6.2.5.1  Test Steps
Hit link of Portal side, Enter Use Name and Password >> Login >> Appointments >> Provide Reason, Provider and Location>>Select Advanced Search �On� >> Provide Select date: From, Keep Select date: To blank >> search 
                 6.2.5.2  Expected Result
It should display validation message �Please select: To date�.*/
@Test (priority = 4)
	public static void blankToDate() throws InterruptedException{
		/*driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptlocation);
		new Select(driver.findElement(By.id("Provider"))).selectByVisibleText(apptprovider);
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
	//	driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
		assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Reason");
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText("06March2017");
	    System.out.println("appt search");
	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    */
		Thread.sleep(20);
	 //   driver.findElement(By.xpath("//input[@id='advanceSearch']")).click();
	    driver.findElement(By.name("monthFrom")).clear();
	    driver.findElement(By.name("monthFrom")).sendKeys("01");
	    driver.findElement(By.name("dateFrom")).clear();
	    driver.findElement(By.name("dateFrom")).sendKeys("31");
	    
	    driver.findElement(By.name("monthTo")).clear();
	    driver.findElement(By.name("monthTo")).sendKeys("00");
	    driver.findElement(By.name("dateTo")).clear();
	    driver.findElement(By.name("dateTo")).sendKeys("0");
	    
	    driver.findElement(By.cssSelector("#searchButton > span")).click();
		System.out.println("search");
		Assert.assertTrue(true, "Please select: To Date");
		Assert.assertEquals(closeAlertAndGetItsText(), "Please select: To Date");
		System.out.println("popup closed");
		test.log(LogStatus.PASS, "Validation working on blank To Date");
	}

	

/*                6.2.6  Test to verify Appointment �From Date� greater than �To Date�.
                 6.2.6.1  Test Steps
Hit link of Portal side, Enter User Name and Password >> Login >> Appointments >> Provide Reason, Provider and Location >> Select Advanced Search �On� >> Provide Select date: From greater than Select date: To >> search.
                 6.2.6.2  Expected Result
It should display validation message �Date is not valid. Please enter valid Date�.*/	
@Test (priority = 5)	
	public static void ToDateGtFromDate() throws InterruptedException{
		/*driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptlocation);
		new Select(driver.findElement(By.id("Provider"))).selectByVisibleText(apptprovider);
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
	//	driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
	//	assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Reason");
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText("06March2017");
	    System.out.println("appt search");
	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    
	    driver.findElement(By.xpath("//input[@id='advanceSearch']")).click();*/
		driver.findElement(By.name("monthFrom")).clear();
	    driver.findElement(By.name("monthFrom")).sendKeys("01");
	    driver.findElement(By.name("dateFrom")).clear();
	    dateCalculation();
	    driver.findElement(By.name("dateFrom")).sendKeys(yesterday);
	    System.out.println("yesterday"+yesterday);
	    
	    driver.findElement(By.name("monthTo")).clear();
	    driver.findElement(By.name("monthTo")).sendKeys("01");
	    driver.findElement(By.name("dateTo")).clear();
	    driver.findElement(By.name("dateTo")).sendKeys("31");
	    new Select(driver.findElement(By.id("d_timeTo"))).selectByVisibleText("12:30 PM");
	   /* driver.findElement(By.xpath("//div[@id='advancedSearch']/table/tbody/tr[2]/td[3]/input[2]")).sendKeys("1");
	    driver.findElement(By.xpath("//div[@id='advancedSearch']/table/tbody/tr/td[3]/input[3]")).sendKeys(yesterday);*/
	    
	    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	    driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
	    
	    System.out.println("search");
		Assert.assertTrue(true, "Date entered is invalid. Please enter valid date.");
		Assert.assertEquals(closeAlertAndGetItsText(), "Date entered is invalid. Please enter valid date.");
		System.out.println("popup closed");
		test.log(LogStatus.PASS, "Validation working on Date");
	}
	
/*                  6.2.7  Test to verify Appointment From Time blank.
                 6.2.7.1  Test Steps
Hit link of Portal side, Enter User Name and Password >> Login >> Appointments >> Provide Reason, Provider and Location >> Select Advanced Search �On� >> Provide Select date: From and To >> Keep Select Time: From blank >> search
                 6.2.7.2  Expected Result
It should display validation message �Please select: from Time�.*/
@Test (priority = 6)
	public static void blankFromTime() throws InterruptedException{
		/*driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptlocation);
		new Select(driver.findElement(By.id("Provider"))).selectByVisibleText(apptprovider);
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
	//	driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
	//	assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Reason");
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText("06March2017");
	    System.out.println("appt search");
	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    
	    driver.findElement(By.xpath("//input[@id='advanceSearch']")).click();*/
		driver.findElement(By.name("dateFrom")).clear();
	    driver.findElement(By.name("dateFrom")).sendKeys("31");
	    new Select(driver.findElement(By.id("d_timeFrom"))).selectByVisibleText("Select Time - - - >");
	    new Select(driver.findElement(By.id("d_timeTo"))).selectByVisibleText("12:30 PM");
	    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	    driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
	    
	    System.out.println("search");
		Assert.assertTrue(true, "Please select: From time");
		Assert.assertEquals(closeAlertAndGetItsText(), "Please select: From time");
		System.out.println("popup closed");
		test.log(LogStatus.PASS, "Validation working on blank From Time");
	}
/*                6.2.8  Test to verify Appointment �To� Time blank.
                 6.2.8.1  Test Steps
Hit link of Portal side, Enter User Name and Password >> Login >> Appointment >> Provide Reason, Provider and Location >> Select Advanced Search �On� >> Provide Select date: From and To >> Provide Select Time: From >> Keep Select Time: To blank >> search.
                 6.2.8.2  Expected Result
It should display validation message �Please select: To Time�.*/	
@Test (priority = 7)	
	public static void blankToTime() throws InterruptedException{
		/*driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptlocation);
		new Select(driver.findElement(By.id("Provider"))).selectByVisibleText(apptprovider);
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
	//	driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
	//	assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Reason");
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText("06March2017");
	    System.out.println("appt search");
	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    
	    driver.findElement(By.xpath("//input[@id='advanceSearch']")).click();*/
	    new Select(driver.findElement(By.id("d_timeFrom"))).selectByVisibleText("09:00 AM");
	    new Select(driver.findElement(By.id("d_timeTo"))).selectByVisibleText("Select Time - - - >");
	    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	    driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
	    
	    System.out.println("search");
		Assert.assertTrue(true, "Please select: To time");
		Assert.assertEquals(closeAlertAndGetItsText(), "Please select: To time");
		System.out.println("popup closed");
		test.log(LogStatus.PASS, "Validation working on blank To Time");
	}

/*                    6.2.9  Test to verify Appointment From Time greater than To Time.
                 6.2.9.1  Test Steps
Hit link of Portal side, Enter User Name and Password >> Login >> Appointments >> Provide Reason, Provider and Location >> Select Advanced Search �On� >> Provide Select date: From and To >> Provide Select Time: From greater than Select Time: To >> search
                 6.2.9.2  Expected Result
It should display validation message �Time is invalid. Please check time�.*/
@Test (priority = 8)	
	public static void ToTimeGtFromTime() throws InterruptedException{
		/*driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptlocation);
		new Select(driver.findElement(By.id("Provider"))).selectByVisibleText(apptprovider);
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
	//	driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
	//	assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Reason");
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText("06March2017");
	    System.out.println("appt search");
	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    
	    driver.findElement(By.xpath("//input[@id='advanceSearch']")).click();*/
	    new Select(driver.findElement(By.id("d_timeFrom"))).selectByVisibleText("12:30 PM");
	    new Select(driver.findElement(By.id("d_timeTo"))).selectByVisibleText("09:00 AM");
	    
	    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	    driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
	    
	    System.out.println("search");
		Assert.assertTrue(true, "Time is invalid Please check time.");
		Assert.assertEquals(closeAlertAndGetItsText(), "Time is invalid Please check time.");
		System.out.println("popup closed");
		test.log(LogStatus.PASS, "Validation working on Time");
	}

/*             6.2.10  Test to verify Appointment Day(s) blank.
                 6.2.10.1  Test Steps
Hit link of Portal side, Enter User Name and Password >> Login >> Appointments >> Provide Reason, Provider and Location >> Select Advanced Search �On� >> Provide Select date: From and To >> Provide Select Time: From and To, Keep Select Day(s) blank >> search
                 6.2.10.2  Expected Result
It should display validation message �Please select Day(s)�.*/
@Test (priority = 9)	
	public static void verifyDaysBlank() throws InterruptedException{
		/*driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptlocation);
		new Select(driver.findElement(By.id("Provider"))).selectByVisibleText(apptprovider);
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
	//	driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
	//	assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Reason");
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText("06March2017");
	    System.out.println("appt search");
	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    
	    driver.findElement(By.xpath("//input[@id='advanceSearch']")).click();*/
	    new Select(driver.findElement(By.id("d_timeFrom"))).selectByVisibleText("09:00 AM");
	    new Select(driver.findElement(By.id("d_timeTo"))).selectByVisibleText("12:30 PM");
	    
	    driver.findElement(By.xpath("//input[@name='mon']")).click();
	    driver.findElement(By.xpath("//input[@name='tue']")).click();
	    driver.findElement(By.xpath("//input[@name='wed']")).click();
	    driver.findElement(By.xpath("//input[@name='thu']")).click();
	    driver.findElement(By.xpath("//input[@name='fri']")).click();
	    driver.findElement(By.xpath("//input[@name='sat']")).click();
	    driver.findElement(By.xpath("//input[@name='sun']")).click();
	    
	    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	    driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
	    
	    System.out.println("search");
		Assert.assertTrue(true, "Please Select Day(s)");
		Assert.assertEquals(closeAlertAndGetItsText(), "Please Select Day(s)");
		System.out.println("popup closed");
		test.log(LogStatus.PASS, "Validation working on Days");
	}

/*             6.2.11  Test to verify Appointment Schedule button.
                 6.2.11.1  Test Steps
Hit link of Patient Portal, Enter User Name and Password >> Login >> Appointments >> Provide Location, Provider and Reason >> Search OR Select Advanced Search �On� >> Provide Select date: From and To>> Provide Select Time: From and To >> Provide Day(s) >> search >> Do not select any appointment >> Click �Schedule�

                 6.2.11.2  Expected Result
It should display validation message �Please select at least one appointment�.*/
@Test (priority = 10)	
	public static void verifyApptSchedule() throws InterruptedException{
		/*driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptlocation);
		new Select(driver.findElement(By.id("Provider"))).selectByVisibleText(apptprovider);
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
	//	driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
	//	assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Reason");
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText("06March2017");
	    System.out.println("appt search");
	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    
	    driver.findElement(By.xpath("//input[@id='advanceSearch']")).click();
	    new Select(driver.findElement(By.id("d_timeFrom"))).selectByVisibleText("09:00 AM");
	    new Select(driver.findElement(By.id("d_timeTo"))).selectByVisibleText("12:30 PM");*/
	    
	    driver.findElement(By.xpath("//input[@name='mon']")).click();
	    driver.findElement(By.xpath("//input[@name='tue']")).click();
	    driver.findElement(By.xpath("//input[@name='wed']")).click();
	    driver.findElement(By.xpath("//input[@name='thu']")).click();
	    driver.findElement(By.xpath("//input[@name='fri']")).click();
	    driver.findElement(By.xpath("//input[@name='sat']")).click();
	    driver.findElement(By.xpath("//input[@name='sun']")).click();
	    
	    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	    driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
	    System.out.println("search");
	    driver.findElement(By.xpath("//a[@id='scheduleAnabled']/span")).click();
		Assert.assertTrue(true, "Please select at least one appointment.");
		Assert.assertEquals(closeAlertAndGetItsText(), "Please select at least one appointment.");
		System.out.println("popup closed");
		test.log(LogStatus.PASS, "Validation working on Days");
	}


// Adv search backdate

	
@AfterMethod
public void afterMethod() {
	 extent.endTest(test);
//	 driver.close();
	 }
@AfterSuite
public void aftetsuite(){
	  
	//  driver.close();
	  test.log(LogStatus.PASS, "Browser closed successfully");
	  extent.flush();
	  extent.close();
}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
