package com.patient.appointment;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.Info;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
//import org.apache.commons.io.FileUtils;

import junit.framework.Assert;

public class AppointmentFunctional extends Info {
	@BeforeSuite
	public void beforesuite(){
	  extent = new ExtentReports("D://Automation_Testing//EclipseProjects//Regression//Result//AppointmentFunctional_report.html",true);
	  extent.loadConfig(new File("D://Automation_Testing//EclipseProjects//Regression//extent-config.xml"));
	}
@BeforeMethod
	public void beforeMethod(Method method) {
		test= extent.startTest((this.getClass().getSimpleName() + " :: " + method.getName()), method.getName());
		test.assignAuthor("Naveen");
		test.assignCategory("AppointmentFunctional test report");
}

@Test(priority = 0)
	public static void Appointmenttab() throws InterruptedException, IOException{   //              6.1.1  Test to verify Appointments Tab 
	login();
	Thread.sleep(20);
	driver.switchTo().defaultContent();
	driver.findElement(By.cssSelector("#appointmentsModule > a > font")).click();
	System.out.println("entered appointment module");
	if(driver.findElement(By.xpath(".//*[@id='searchButton']/span")).isDisplayed()){
		System.out.println("Appointment Tab Verification - success");
		test.log(LogStatus.PASS, "Appointment Tab Verification - success");
		
		}else{
			System.out.println("Appointment Tab Verification - failed");
			test.log(LogStatus.FAIL, "Appointment Tab Verification - failed");
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\Appointmenttab1.png"), true);
		}
}

/*             6.1.9  Test to verify scheduled appointments frame when no appointment is scheduled for the logged in patient 
6.1.9.1  Test Steps
Access Patient Portal Link >> Enter the registered Username and Password >> Sign In >> Appointment tab >> Scheduled Appointments Tab 
6.1.9.2  Expected Result
It should show �No Scheduled Appointments� in scheduled appointment frame
*/
@Test (priority = 1)
	public static void verifyScheduledApptGrid() throws InterruptedException, IOException{
		//div[contains(text(), "No Scheduled Appointments")]
		
		//   .//*[@id='scehduledAppGrid']/div/div/table/tbody/tr[2]/td
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		
		Thread.sleep(200);	
		if(driver.findElement(By.xpath(".//*[@id='scehduledAppGrid']/div/div/table/tbody/tr[2]/td")).getText().equalsIgnoreCase("No Scheduled Appointments")){
			System.out.println("Grid not have appointments");
			test.log(LogStatus.PASS, "Grid not have appointments");
			}else{
			System.out.println("grid have appointments");
			test.log(LogStatus.FAIL, "grid have appointments");
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyScheduledApptGrid1.png"), true);
			}
		}


@Test(priority = 2)		
	public static void ApptSearch() throws InterruptedException, IOException{   //                6.1.2  Test to verify that Appointment slots should remain displayed after  �Book An Appointment� is performed.
	driver.switchTo().defaultContent();
	driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
	System.out.println("entered appointment module");
	  new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptlocation);
	    new Select(driver.findElement(By.id("Provider"))).selectByVisibleText(apptprovider);
	    Thread.sleep(20);
	    new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
		driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
		assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Reason");
	//	assertEquals(closeAlertAndGetItsText(), "Please Select Day(s)");
		Thread.sleep(20);
	    new Select(driver.findElement(By.id("reason"))).selectByVisibleText("06March2017");
    System.out.println("appt search");
    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    
    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
    System.out.println("searchaaaaaaaa");
		
		Thread.sleep(20);
	    new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
	    System.out.println("appt search");
	    System.out.println("searchaaaaaaaa");
	 //   assertEquals(closeAlertAndGetItsText(), "Please Select Day(s)");
	    driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
		long timeoutInSeconds = 30;
		WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='scheduleAnabled']/span")));
		
		if(driver.findElement(By.xpath(".//*[@id='nextAvailableAppGrid']/div/table/tbody/tr[1]/td/font")).getText().equalsIgnoreCase("Select your appointment choice and then click Book Appointment")){
			System.out.println("Next available Appointments are displayed");
			test.log(LogStatus.PASS, "Next available Appointments are displayed");
			
			}else{
				System.out.println("Next available Appointments - failed");
				test.log(LogStatus.FAIL, "Next available Appointments - failed");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\ApptSearch1.png"), true);
			}
	}

@Test(priority = 3)
	public static void AdvSearch() throws InterruptedException, IOException{   //              6.1.3  Test to verify Advanced Search option
	driver.switchTo().defaultContent();
	driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
	System.out.println("entered appointment module");
	  new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptlocation);
	    new Select(driver.findElement(By.id("Provider"))).selectByVisibleText(apptprovider);
	    Thread.sleep(20);
	    new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
		driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
		assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Reason");
	//	assertEquals(closeAlertAndGetItsText(), "Please Select Day(s)");
		Thread.sleep(20);
	    new Select(driver.findElement(By.id("reason"))).selectByVisibleText("06March2017");
    System.out.println("appt search");
    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    
    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
    System.out.println("searchaaaaaaaa");
	
		Thread.sleep(20);
	    new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
	    driver.findElement(By.xpath("//input[@id='advanceSearch']")).click();
	    
	    if(driver.findElement(By.xpath("//img[@id='calender']")).isDisplayed()){
			System.out.println("Advanced Search options showing");
			test.log(LogStatus.PASS, "Advanced Search options showing");
			
			}else{
				System.out.println("Advanced Search options showing - failed");
				test.log(LogStatus.FAIL, "Advanced Search options showing - failed");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\AdvSearch1.png"), true);
			}
	    
	    
	}
	
@Test(priority = 4)
public static void AdvSearchdays() throws Exception{   //             6.1.4  Test to verify Option to select Days 
	login();
	driver.switchTo().defaultContent();
	driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
	System.out.println("entered appointment module");
	  new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptlocation);
	    new Select(driver.findElement(By.id("Provider"))).selectByVisibleText(apptprovider);
	    Thread.sleep(20);
	    new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
		driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
		assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Reason");
	//	assertEquals(closeAlertAndGetItsText(), "Please Select Day(s)");
		Thread.sleep(20);
	    new Select(driver.findElement(By.id("reason"))).selectByVisibleText("06March2017");
    System.out.println("appt search");
    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    
    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
    System.out.println("searchaaaaaaaa");
 //   assertEquals(closeAlertAndGetItsText(), "Please Select Day(s)");
    driver.findElement(By.xpath("//input[@id='advanceSearch']")).click();
    if(!driver.findElement(By.xpath("//input[@name='mon']")).isSelected() &&
			!driver.findElement(By.xpath("//input[@name='tue']")).isSelected() &&
			!driver.findElement(By.xpath("//input[@name='wed']")).isSelected() &&
			!driver.findElement(By.xpath("//input[@name='thu']")).isSelected() &&
			!driver.findElement(By.xpath("//input[@name='fri']")).isSelected() &&
			!driver.findElement(By.xpath("//input[@name='sat']")).isSelected() &&
			!driver.findElement(By.xpath("//input[@name='sun']")).isSelected()){
		System.out.println("All Days are verified and selected");
		test.log(LogStatus.PASS, "All Days are verified and selected");
	}else{
		System.out.println("All Days are verified and some days are not selected");
		test.log(LogStatus.PASS, "All Days are verified and some days are not selected");
		
	}

   /* 
    WebElement mon = driver.findElement(By.xpath("//input[@name='mon']"));
    WebElement tue = driver.findElement(By.xpath("//input[@name='tue']"));
    WebElement wed = driver.findElement(By.xpath("//input[@name='wed']"));
    WebElement thu = driver.findElement(By.xpath("//input[@name='thu']"));
    WebElement fri = driver.findElement(By.xpath("//input[@name='fri']"));
    WebElement sat = driver.findElement(By.xpath("//input[@name='sat']"));
    WebElement sun = driver.findElement(By.xpath("//input[@name='sun']"));
    WebElement[] elements  = { mon, tue, wed, thu, fri, sat, sun };
	safeSelectCheckBoxes(10, elements );
	test.log(LogStatus.PASS, "All Days are verified and selected");*/
	//safeDe
	 
//	oSelect.deselectAll;
    
}


/*6.1.5  Test to verify Appointment scheduling using select Days. 
6.1.5.1  Test Steps
         Access Patient Portal Link >> Enter the registered Username and Password >> Sign In >> Appointment tab >> Scheduled an Appointment frame >> select Location, provider, Reason >> Click on Advanced search check box >>select Dates>>Select time>>Now uncheck some of the days>>Search
6.1.5.2  Expected Result
         All required appointment slots do get displayed properly.*/

// working on              6.1.5  Test to verify Appointment scheduling using select Days.
//  here am trying to work on logic it will select only today 
@Test(priority = 5)
	public static void AdvSearchselectdays() throws Exception{ 
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptlocation);
		new Select(driver.findElement(By.id("Provider"))).selectByVisibleText(apptprovider);
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
		driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
		assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Reason");
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText("06March2017");
	    System.out.println("appt search");
	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    
	    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	   // driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
	    System.out.println("searchaaaaaaaa");
	 //   assertEquals(closeAlertAndGetItsText(), "Please Select Day(s)");
	
	    driver.findElement(By.xpath("//input[@id='advanceSearch']")).click();
	    driver.findElement(By.xpath("(//img[@alt='Calendar'])[2]")).click();
	    driver.findElement(By.xpath("//div[@id='calendarDiv']/div[5]/table/tbody/tr[6]/td[4]")).click();
	    new Select(driver.findElement(By.id("d_timeFrom"))).selectByVisibleText("09:00 AM");
	    new Select(driver.findElement(By.id("d_timeTo"))).selectByVisibleText("12:30 PM");
	    driver.findElement(By.xpath("//input[@name='tue']")).click();
	    driver.findElement(By.xpath("//input[@name='thu']")).click();
	    driver.findElement(By.xpath("//input[@name='sat']")).click();
	    driver.findElement(By.xpath("//input[@name='mon']")).click();
	    
	    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	    driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
	    
	    if(driver.findElement(By.xpath("//a[@id='scheduleAnabled']/span")).isDisplayed()){
			System.out.println("Next available Appointments are displayed");
			test.log(LogStatus.PASS, "Next available Appointments are displayed");
			
			}else{
				System.out.println("Next available Appointments - failed");
				test.log(LogStatus.FAIL, "Next available Appointments - failed");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\AdvSearchselectdays1.png"), true);
			}
	    
	}


// Scheduling an appointment
@Test(priority = 6)	
	public static void Schedulingappt() throws InterruptedException, IOException{
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptlocation);
		new Select(driver.findElement(By.id("Provider"))).selectByVisibleText(apptprovider);
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
		driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
	//	assertEquals(closeAlertAndGetItsText(), "Please Select Day(s)");
		assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Reason");
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText("06March2017");
	    System.out.println("appt search");
	    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	
	    driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
	    driver.findElement(By.xpath("//input[@id='schappt']")).click();
	    driver.findElement(By.xpath("//a[@id='scheduleAnabled']/span")).click();
	    
	    int total_frames=driver.findElements(By.tagName("iframe")).size();
	    System.out.println("frames"+total_frames);
	    driver.switchTo().frame(0);
	    driver.findElement(By.xpath(".//*[@id='newFormFrame']/div[2]/table/tbody/tr[3]/td/a[2]/span")).click();
		System.out.println("skip button clicked"); 
		driver.switchTo().defaultContent();
	    
	    Thread.sleep(200);
	    if(driver.findElement(By.xpath("//a[@id='cancelEnebled']/span")).isDisplayed()){
			System.out.println("Scheduled Appointments are displayed");
			test.log(LogStatus.PASS, "Scheduled Appointments are displayed");
			
			}else{
				System.out.println("Scheduled Appointments - failed");
				test.log(LogStatus.FAIL, "Scheduled Appointments - failed");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\Schedulingappt1.png"), true);
			}
	    
	}


/*             6.1.6  To verify 'Next available appointment' as well as 'Schedule Appointment' contents get disappear.
                 6.1.6.1  Test Steps
Hit link of Portal side, Enter User Name and Password >> Login >> Appointment >> Provide Reason, Provider and Location >> Search >> Once again select new Location/Provider/ reason 
                 6.1.6.2  Expected Result
As soon as student selects new Location, �Next available appointment'  should disappear and get set to blank.  */
@Test(priority = 7)	
	public static void isVisibleOfNextAvailableAppt() throws InterruptedException, IOException{
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptnewlocation);
		new Select(driver.findElement(By.id("Provider"))).selectByVisibleText(apptprovider);
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
		boolean b= driver.findElement(By.xpath(".//*[@id='nextAvailableAppGrid']/div")) != null;
		if(b==false){
			System.out.println("Next available Appointments are displayed");
			test.log(LogStatus.FAIL, "Next available Appointments are displayed");
			
			}else{
				System.out.println("Next available Appointments are not displayed");
				test.log(LogStatus.PASS, "Next available Appointments are not displayed");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\isVisibleOfNextAvailableApp1.png"), true);
			}
		
}


/*              6.1.7  Test to search an appointment 
                 6.1.7.1  Test Steps
Access Patient Portal Link>>Enter the registered Username and Password>>Sign In>>Appointment tab >>Scheduled an Appointment frame >> select Location, provider, Reason>> Click on Advanced search check box >> Select Date, Time and Days >> click on search
                 6.1.7.2  Expected Result
It should show available time slots in next available appointment frame as per the selected filters. The page should jump to the next available appointment results once the page reloads. */







@Test(priority = 8)	
	public void AdvanceSearch() throws InterruptedException, IOException{ 
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptlocation);
		new Select(driver.findElement(By.id("Provider"))).selectByVisibleText(apptprovider);
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
	//	driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
	//	assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Reason");
		Thread.sleep(20);
		new Select(driver.findElement(By.id("reason"))).selectByVisibleText("06March2017");
	    System.out.println("appt search");
	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    
	    driver.findElement(By.xpath("//input[@id='advanceSearch']")).click();
	    driver.findElement(By.xpath("(//img[@alt='Calendar'])[2]")).click();
	    driver.findElement(By.xpath("//div[@id='calendarDiv']/div[5]/table/tbody/tr[6]/td[4]")).click();
	    new Select(driver.findElement(By.id("d_timeFrom"))).selectByVisibleText("09:00 AM");
	    new Select(driver.findElement(By.id("d_timeTo"))).selectByVisibleText("12:30 PM");
	    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	    driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
	    
	    if(driver.findElement(By.xpath("//a[@id='scheduleAnabled']/span")).isDisplayed()){
			System.out.println("Next available Appointments are displayed");
			test.log(LogStatus.PASS, "Next available Appointments are displayed");
			
			}else{
				System.out.println("Next available Appointments - failed");
				test.log(LogStatus.FAIL, "Next available Appointments - failed");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\AdvanceSearch1.png"), true);
			}
	    
	}
	
	
/*              6.1.8  To verify Last used Provider and Location should display if Booked Appointment Grid is full.
                 6.1.8.1  Test Steps
Hit link of Patient Portal>>Enter User Name and Password>>Sign In>>Appointment>> Select Appointment Location L1, Provider P1 & Reason R1>>Search>>Schedule 5 appointments>>Exit 
& Re-login>>appointments Tab>> Select Appointment Location L2, Provider P2 & Reason R2>>Search>>Schedule an appointment>>Exit 
& Re-login>>appointments Tab>>Click �Next� from Booked appointments panel.
                 6.1.8.2  Expected Result
It should not crash the application & clicking Next button should display remaining booked appointments.   */	
		

@Test (priority = 9)
	public static void triceLoginAppt() throws InterruptedException, IOException{
	//	login();
		Thread.sleep(20);
		 
			driver.switchTo().defaultContent();
			driver.findElement(By.cssSelector("#appointmentsModule > a > font")).click();
			System.out.println("entered appointment module");
			new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptlocation);
			new Select(driver.findElement(By.id("Provider"))).selectByVisibleText(apptprovider);
			Thread.sleep(20);
			new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason);
			driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
			
		//		assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Reason");
			assertEquals(closeAlertAndGetItsText(), "Please Select Day(s)");
		
			//	assertEquals(foundAlertText(), "Please Select Appointment Reason");
				
			Thread.sleep(20);
			new Select(driver.findElement(By.id("reason"))).selectByVisibleText("06March2017");
		    System.out.println("appt search");
		    driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
		    for(int i=1;i<=5;i++){ 
		    driver.findElement(By.xpath("//input[@id='schappt']")).click();
		    driver.findElement(By.xpath("//a[@id='scheduleAnabled']/span")).click();
		    
		    int total_frames=driver.findElements(By.tagName("iframe")).size();
		    System.out.println("frames"+total_frames);
		    driver.switchTo().frame(0);
		    driver.findElement(By.xpath(".//*[@id='newFormFrame']/div[2]/table/tbody/tr[3]/td/a[2]/span")).click();
			System.out.println("skip button clicked"); 
			driver.switchTo().defaultContent();
		    Thread.sleep(200);   
		    }
		driver.findElement(By.xpath("//td[6]/div/a/font")).click();   // logout
		
		loginAgain();
		Thread.sleep(20);
		
			driver.switchTo().defaultContent();
			driver.findElement(By.cssSelector("#appointmentsModule > a > font")).click();
			System.out.println("entered appointment module");
			new Select(driver.findElement(By.id("Location"))).selectByVisibleText(apptlocation2);
			new Select(driver.findElement(By.id("Provider"))).selectByVisibleText(apptprovider2);
			Thread.sleep(20);
			new Select(driver.findElement(By.id("reason"))).selectByVisibleText(apptreason2);
			driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
			
			assertEquals(closeAlertAndGetItsText(), "Please Select Appointment Reason");			
			Thread.sleep(20);
			new Select(driver.findElement(By.id("reason"))).selectByVisibleText("X Ray");
		    System.out.println("appt search");
		    driver.findElement(By.xpath(".//*[@id='searchButton']/span")).click();
		    for(int j=1;j<=5;j++){  
		    driver.findElement(By.xpath("//input[@id='schappt']")).click();
		    driver.findElement(By.xpath("//a[@id='scheduleAnabled']/span")).click();
		    
		    int total_frames=driver.findElements(By.tagName("iframe")).size();
		    System.out.println("frames"+total_frames);
		    driver.switchTo().frame(0);
		    driver.findElement(By.xpath(".//*[@id='newFormFrame']/div[2]/table/tbody/tr[3]/td/a[2]/span")).click();
			System.out.println("skip button clicked"); 
			driver.switchTo().defaultContent();
		    Thread.sleep(200);   
		    }
		driver.findElement(By.xpath("//td[6]/div/a/font")).click();   // logout
		loginAgain();
		Thread.sleep(20);
		driver.findElement(By.cssSelector("#appointmentsModule > a > font")).click();
		driver.findElement(By.xpath("//div[@id='SHL_pagination']/a/img")).click();
		System.out.println("application working fine");
		
		 Thread.sleep(200);
		    if(driver.findElement(By.xpath("//a[@id='cancelEnebled']/span")).isDisplayed()){
				System.out.println("Scheduled Appointments are displayed");
				test.log(LogStatus.PASS, "Scheduled Appointments are displayed");
				
				}else{
					System.out.println("Scheduled Appointments - failed");
					test.log(LogStatus.FAIL, "Scheduled Appointments - failed");
					File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\triceLoginAppt1.png"), true);
				}
}


/*              6.1.10  Test to verify Appointments created for one day before from current date should remain in scheduled appointment when scheduling current date appointment 
                 6.1.10.1  Test Steps
Access Patient Portal Link >> Enter the registered Username and Password who has already scheduled an appointment >> Now, schedule an appointment for current date
                 6.1.10.2  Expected Result
Observe scheduled appointment frame, Already scheduled appointment for past should not get cleared */
	/*public static void verifyScheduleGrid(){
	//	.//*[@id='scehduledAppGrid']/div/div
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		
		if(driver.findElement(By.xpath(".//*[@id='scehduledAppGrid']/div/div")).getText().equalsIgnoreCase("No Scheduled Appointments")){
			System.out.println("Grid not have appointments");
				}else{
				System.out.println("grid have appointments");
				}
	}
*/



/*              6.1.11  Test to Verify paging format for scheduled appointment list 
                 6.1.11.1  Test Steps
Access Patient Portal Link >> Enter the registered Username and Password >> Sign In >> Appointment tab >> Scheduled Appointment frame >> verify if more than 5 appointments are already scheduled
                 6.1.11.2  Expected result
It should show next button on the top of all the appointment in the same frame   */
@Test (priority = 10)
	public static void verifyScheduledApptList() throws InterruptedException, IOException{
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		
		 Thread.sleep(200);
		    if(driver.findElement(By.xpath("//div[@id='SHL_pagination']/a/img")).isDisplayed()){
				System.out.println("Scheduled Appointments grid showing Next button");
				test.log(LogStatus.PASS, "Scheduled Appointments grid showing Next button");
				
				}else{
					System.out.println("Scheduled Appointments grid not showing Next button");
					test.log(LogStatus.FAIL, "Scheduled Appointments grid not showing Next button");
					File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyScheduledApptList1.png"), true);
				}
	}




/*              6.1.12  Test to verify cancel button on Scheduled appointment frame
                 6.1.12.1  Test Steps
Access Patient Portal Link >> Enter the registered Username and Password >> Sign In >> Appointment tab >> Scheduled Appointment frame >> Select an appointment >> click on cancel appointment button
                 6.1.12.2  Expected Result
It should show confirmation to cancel appointment
                 6.1.12.3  Test Steps	
Access Patient Portal Link>>Enter the registered Username and Password>>Sign In>>Appointment tab >>Scheduled Appointment frame >>Select an appointment >> click on cancel appointment button >>Click ok in confirmation message
                 6.1.12.4  Expected Result
It should cancel selected appointment and remove it from scheduled appointment list  */


@Test (priority = 11)
	public static void verifyCancleScheduledAppList() throws InterruptedException, IOException{
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//div[@id='appointmentsModule']/a/font")).click();
		System.out.println("entered appointment module");
		boolean s= driver.findElement(By.xpath("//tbody[@id='scheduledapp']/tr/td/input")) != null;
		for(int j=1;j<=5;j++){
			if(s==true){
				driver.findElement(By.xpath("//tbody[@id='scheduledapp']/tr/td/input")).click();
				driver.findElement(By.xpath("//a[@id='cancelEnebled']/span")).click();
				assertEquals(closeAlertAndGetItsText(), "Are you sure you want to cancel your appointment? ");
				assertEquals(closeAlertAndGetItsText(), "Selected appointment deleted");
				System.out.println("appointment deleted  "+j);
				}else{
					System.out.println("Grid is empty");
				}
			}
		Thread.sleep(200);
	    if(driver.findElement(By.xpath("//a[@id='cancelEnebled']/span")).isEnabled()){
			System.out.println("Scheduled Appointments grid is not empty, and it have some appointments");
			test.log(LogStatus.PASS, "Scheduled Appointments grid is not empty, and it have some appointments");
			
			}else{
				System.out.println("Scheduled Appointments grid is empty");
				test.log(LogStatus.FAIL, "Scheduled Appointments grid is empty");
				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(scrFile, new File("D:\\Automation_Testing\\EclipseProjects\\Regression\\Screenshots\\verifyCancleScheduledAppList1.png"), true);
			}
	}











public static void loginAgain() throws InterruptedException{
	driver.get(baseUrl);
	System.out.println("URL loaded");
	driver.findElement(By.id("userName")).clear();
	driver.findElement(By.id("userName")).sendKeys(username);
	driver.findElement(By.id("Password")).clear();
	driver.findElement(By.id("Password")).sendKeys(Password);
	driver.findElement(By.className("NWebButton3NewPrimary")).click();
	System.out.println("login success");
	test.log(LogStatus.PASS, "login success");
			
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	boolean pgsql=driver.findElements(By.xpath("//span/b")).size()!= 0; 
	if(pgsql==false){
		System.out.println("if condition");
		framecount();
	} else {
		System.out.println("else condition");
		driver.findElement(By.xpath("//span/b")).click();
//		System.out.println("selected postgres in combo box");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		framecount();
	}
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.switchTo().defaultContent();
	long timeoutInSeconds = 30;
	WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='messagesModule']/a/font")));
	WebElement element= driver.findElement(By.xpath("//a/div"));
	element.isDisplayed();
}

@AfterMethod
public void afterMethod() {
	 extent.endTest(test);
}
@AfterSuite
public void aftetsuite(){
	  
	//  driver.close();
	  test.log(LogStatus.PASS, "Browser closed successfully");
	  extent.flush();
	  extent.close();
}
}
